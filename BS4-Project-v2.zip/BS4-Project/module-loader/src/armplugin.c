#include <jni.h>
static volatile unsigned loaded;
static unsigned append(char *s,unsigned p,const char *v){while(*v)s[p++]=*v++;return p;}
static unsigned hex(char *s,unsigned p,unsigned v){const char *h="0123456789abcdef";for(int i=7;i>=0;i--)s[p++]=h[(v>>(i*4))&15];return p;}
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm,void *reserved){loaded++;return JNI_VERSION_1_6;}
JNIEXPORT jstring JNICALL Java_org_example_bs4armprobe_MainActivity_pluginResult(JNIEnv *env,jclass cls,jint nonce){
 char result[160];unsigned p=append(result,0,"ARM32_PLUGIN_OK pointer_bytes=");result[p++]='0'+sizeof(void*);
 p=append(result,p," onload=");result[p++]='0'+loaded;
 p=append(result,p," nonce=");p=hex(result,p,(unsigned)nonce);
 p=append(result,p," response=");p=hex(result,p,((unsigned)nonce)^0xa55a1234u);result[p]=0;
 return (*env)->NewStringUTF(env,result);
}
