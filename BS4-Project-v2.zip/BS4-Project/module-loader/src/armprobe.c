#include <jni.h>
static volatile unsigned char payload[256];
static char report[256];
static unsigned append(char *d,unsigned p,const char *s){while(*s)d[p++]=*s++;return p;}
static unsigned hex(char *d,unsigned p,unsigned v){const char *h="0123456789abcdef";for(int i=7;i>=0;i--)d[p++]=h[(v>>(i*4))&15];return p;}
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm,void *reserved){return JNI_VERSION_1_6;}
JNIEXPORT jstring JNICALL Java_org_example_bs4armprobe_MainActivity_runNative(JNIEnv *env,jclass cls){
 unsigned seed=0x13579bdf,check=2166136261u;
 for(unsigned i=0;i<256;i++){seed=seed*1664525u+1013904223u;payload[i]=(unsigned char)(seed>>24);check=(check^payload[i])*16777619u;}
 unsigned p=0;
 p=append(report,p,"ARM32_NATIVE_OK pointer_bytes=");report[p++]='0'+sizeof(void*);
 p=append(report,p," buffer=0x");p=hex(report,p,(unsigned)payload);
 p=append(report,p," checksum=0x");p=hex(report,p,check);report[p]=0;
 return (*env)->NewStringUTF(env,report);
}
