package org.example.bs4armprobe;
import android.app.Activity;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.widget.TextView;
import java.io.*;
public final class MainActivity extends Activity {
 private static native String runNative();
 private static native String pluginResult(int nonce);
 private static final String PLUGIN_SHA256="d99f887ba47efbb6711cd31e44540eb7d89f292bda379b7097652ff2f89e9921";
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  StringBuilder r=new StringBuilder("BS4 ARM32 own-app execution test\nPID="+Process.myPid()+"\n");
  boolean pass=false;
  try {
   System.loadLibrary("armprobe");
   String nativeResult=runNative();
   r.append(nativeResult).append('\n');
   pass=nativeResult.startsWith("ARM32_NATIVE_OK pointer_bytes=4 ") && nativeResult.endsWith("checksum=0x1d655466");
   int start=nativeResult.indexOf("buffer=0x")+9;
   long address=Long.parseLong(nativeResult.substring(start,start+8),16);
   byte[] bytes=new byte[256];
   RandomAccessFile mem=new RandomAccessFile("/proc/self/mem","r");mem.seek(address);mem.readFully(bytes);mem.close();
   long checksum=2166136261L;
   for(byte value:bytes) checksum=((checksum^(value&255))*16777619L)&0xffffffffL;
   boolean pointerPass=checksum==0x1d655466L;
   pass=pass && pointerPass;
   r.append("Independent Java read /proc/self/mem at ARM pointer: ").append(pointerPass?"PASS":"FAIL").append(" checksum=0x").append(Long.toHexString(checksum)).append('\n');
   RandomAccessFile elf=new RandomAccessFile(getApplicationInfo().nativeLibraryDir+"/libarmprobe.so","r");
   byte[] header=new byte[20];elf.readFully(header);elf.close();
   boolean elfPass=header[0]==127 && header[1]==69 && header[2]==76 && header[3]==70 && header[4]==1 && header[5]==1 && header[18]==40 && header[19]==0;
   pass=pass && elfPass;
   r.append("Installed library ELF32 ARM header: ").append(elfPass?"PASS":"FAIL").append('\n');
   r.append("Own process library mappings:\n");
   BufferedReader reader=new BufferedReader(new FileReader("/proc/self/maps"));
   String line;
   while((line=reader.readLine())!=null) if(line.contains("libarmprobe")||line.contains("libhoudini")||line.contains("libnb.so")) r.append(line).append('\n');
   reader.close();
  } catch(Throwable t) {
   pass=false;
   r.append("ERROR: ").append(Log.getStackTraceString(t)).append('\n');
  }
  r.append(pass?"RESULT: ARM32 EXECUTION AND OWN POINTER READ PASS\n":"RESULT: ARM32 EXECUTION OR OWN POINTER READ FAIL\n");
  if(getIntent().getBooleanExtra("load_plugin",false)) {
   boolean loaded=false;
   try {
    if(!pass) throw new IOException("Base ARM32 test failed");
    File incoming=new File(getExternalFilesDir(null),"libarmplugin.so");
    if(incoming.length()<20 || incoming.length()>1048576) throw new IOException("Missing module or invalid length");
    FileInputStream input=new FileInputStream(incoming);
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] chunk=new byte[4096];int n;
    try {while((n=input.read(chunk))!=-1){bytes.write(chunk,0,n);if(bytes.size()>1048576)throw new IOException("Module too large");}} finally {input.close();}
    byte[] binary=bytes.toByteArray();
    byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest(binary);
    StringBuilder hash=new StringBuilder();for(byte value:digest)hash.append(String.format(java.util.Locale.US,"%02x",value&255));
    if(!hash.toString().equals(PLUGIN_SHA256))throw new SecurityException("Module SHA256 mismatch");
    r.append("MODULE SHA256 VERIFIED: ").append(hash).append('\n');
    File destination=new File(getDir("probe_modules",MODE_PRIVATE),"libarmplugin.so");
    FileOutputStream write=new FileOutputStream(destination);try{write.write(binary);write.getFD().sync();}finally{write.close();}
    System.load(destination.getAbsolutePath());
    int nonce=new java.security.SecureRandom().nextInt();
    String answer=pluginResult(nonce);
    String expected=String.format(java.util.Locale.US,"ARM32_PLUGIN_OK pointer_bytes=4 onload=1 nonce=%08x response=%08x",nonce,nonce^0xa55a1234);
    r.append(answer).append('\n');
    if(!answer.equals(expected))throw new IOException("JNI response mismatch");
    BufferedReader maps=new BufferedReader(new FileReader("/proc/self/maps"));boolean mapped=false;String line;
    try {while((line=maps.readLine())!=null)if(line.contains("/libarmplugin.so")){r.append(line).append('\n');mapped=true;}}finally{maps.close();}
    if(!mapped)throw new IOException("Loaded module absent from own process maps");
    loaded=true;
   } catch(Throwable t) { r.append("MODULE ERROR: ").append(Log.getStackTraceString(t)).append('\n'); }
   r.append(loaded?"RESULT: OWN ARM32 MODULE LOAD PASS\n":"RESULT: OWN ARM32 MODULE LOAD FAIL\n");
  }
  r.append("Scope: normal JNI loading and independent own-process pointer read. This run does not test external PID memory access or injection. Module loading uses this own application interface.\n");
  try { FileOutputStream f=openFileOutput("arm32-report.txt",MODE_PRIVATE); f.write(r.toString().getBytes("UTF-8")); f.close(); }
  catch(Exception e){r.append("Report save error: ").append(e).append('\n');}
  try { File dir=getExternalFilesDir(null); if(dir==null) throw new IOException("External files unavailable"); FileOutputStream f=new FileOutputStream(new File(dir,"arm32-report.txt")); f.write(r.toString().getBytes("UTF-8")); f.close(); } catch(Exception e){r.append("External report save error: ").append(e).append('\n');}
  for(String line:r.toString().split("\n")) Log.i("BS4ArmProbe",line);
  TextView view=new TextView(this);view.setText(r.toString());view.setTextSize(14);view.setPadding(20,20,20,20);setContentView(view);
 }
}
