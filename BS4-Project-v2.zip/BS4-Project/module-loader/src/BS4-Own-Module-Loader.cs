using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading;
class ModuleTest {
 const string Package="org.example.bs4armprobe";
 const string RemoteDir="/sdcard/Android/data/org.example.bs4armprobe/files";
 const string Hash="d99f887ba47efbb6711cd31e44540eb7d89f292bda379b7097652ff2f89e9921";
 static readonly string Folder=AppDomain.CurrentDomain.BaseDirectory;
 static readonly StringBuilder Log=new StringBuilder();
 static string Adb,Serial;
 static void Say(string s){Console.WriteLine(s);Log.AppendLine(s);}
 static string Run(string args,int timeout){
  ProcessStartInfo start=new ProcessStartInfo(Adb,args){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};
  StringBuilder output=new StringBuilder();
  using(Process p=new Process()){
   p.StartInfo=start;p.OutputDataReceived+=(s,e)=>{if(e.Data!=null)lock(output)output.AppendLine(e.Data);};p.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)lock(output)output.AppendLine(e.Data);};
   p.Start();p.BeginOutputReadLine();p.BeginErrorReadLine();
   if(!p.WaitForExit(timeout)){try{p.Kill();}catch{}throw new Exception("ADB timeout: "+args);}
   p.WaitForExit();if(p.ExitCode!=0)throw new Exception("ADB failed: "+args+"\n"+output);return output.ToString().Replace("\r","");
  }
 }
 static string Shell(string cmd){return Run("-s "+Serial+" shell "+cmd,10000);}
 static void Select(){
  Adb=new string[]{@"C:\Program Files\BlueStacks_bgp64\HD-Adb.exe",@"C:\Program Files\BlueStacks\HD-Adb.exe"}.FirstOrDefault(File.Exists);
  if(Adb==null)throw new Exception("BlueStacks HD-Adb.exe not found");
  List<string> responding=new List<string>();
  foreach(string line in Run("devices",10000).Split('\n')){
   Match m=Regex.Match(line.Trim(),@"^([A-Za-z0-9._:-]+)\s+device$");if(!m.Success)continue;string serial=m.Groups[1].Value;
   try{if(Run("-s "+serial+" shell id",3000).Contains("uid="))responding.Add(serial);}catch(Exception e){Say("Skip "+serial+": "+e.Message);}
  }
  if(responding.Count!=1)throw new Exception("Expected one responding emulator, found "+responding.Count);Serial=responding[0];Say("ADB device="+Serial);
 }
 static string Sha(byte[] data){using(SHA256 s=SHA256.Create())return BitConverter.ToString(s.ComputeHash(data)).Replace("-","").ToLowerInvariant();}
 static void CheckLocal(){
  byte[] data=File.ReadAllBytes(Path.Combine(Folder,"libarmplugin.so"));
  if(data.Length<40||data[0]!=127||data[1]!=69||data[2]!=76||data[3]!=70||data[4]!=1||data[5]!=1||BitConverter.ToUInt16(data,18)!=40||BitConverter.ToUInt32(data,36)>>24!=5)
   throw new Exception("Module must be ELF32 ARM EABI5");
  if(Sha(data)!=Hash)throw new Exception("Unexpected local module SHA256");
  if(!File.Exists(Path.Combine(Folder,"BS4-ARM32-Module-Test.apk")))throw new Exception("Companion APK missing");
  Say("LOCAL FILE CHECK PASS: ELF32 ARM EABI5; pinned SHA256 matches.");
 }
 static string ReadFresh(){
  Stopwatch clock=Stopwatch.StartNew();string last="";
  while(clock.Elapsed.TotalSeconds<15){
   try{string text=Shell("cat "+RemoteDir+"/arm32-report.txt");if(text.Contains("RESULT: OWN ARM32 MODULE LOAD"))return text;last=text;}catch(Exception e){last=e.Message;}
   Thread.Sleep(300);
  }
  throw new Exception("No fresh module report: "+last);
 }
 static void Test(string mode){
  Say("CASE="+mode);Shell("am force-stop "+Package);Shell("mkdir -p "+RemoteDir);Shell("rm -f "+RemoteDir+"/arm32-report.txt "+RemoteDir+"/libarmplugin.so");
  string local=Path.Combine(Folder,"libarmplugin.so"),temporary=null;
  try{
   if(mode=="corrupt"){
    byte[] bad=File.ReadAllBytes(local);bad[bad.Length-1]^=1;temporary=Path.Combine(Folder,"corrupt-"+Guid.NewGuid().ToString("N")+".so");File.WriteAllBytes(temporary,bad);local=temporary;
   }
   if(mode!="missing")Run("-s "+Serial+" push \""+local+"\" "+RemoteDir+"/libarmplugin.so",20000);
  }finally{if(temporary!=null&&File.Exists(temporary))File.Delete(temporary);}
  Say(Shell("am start -W -n "+Package+"/.MainActivity --ez load_plugin true").Trim());
  string report=ReadFresh();
  File.WriteAllText(Path.Combine(Folder,"module-"+mode+"-report.txt"),report,new UTF8Encoding(false));Say(report.Trim());
  Match pid=Regex.Match(report,@"^PID=(\d+)$",RegexOptions.Multiline);
  if(!pid.Success||Shell("pidof "+Package).Trim()!=pid.Groups[1].Value)throw new Exception("Report PID is not the current own app");
  if(!report.Contains("RESULT: ARM32 EXECUTION AND OWN POINTER READ PASS"))throw new Exception("Base ARM32 app failed");
  if(mode=="positive"){
   Match reply=Regex.Match(report,@"ARM32_PLUGIN_OK pointer_bytes=4 onload=1 nonce=([0-9a-f]{8}) response=([0-9a-f]{8})");
   if(!report.Contains("RESULT: OWN ARM32 MODULE LOAD PASS")||!report.Contains("MODULE SHA256 VERIFIED: "+Hash)||!reply.Success||!report.Contains("/libarmplugin.so"))throw new Exception("Positive module test failed");
   if((Convert.ToUInt32(reply.Groups[1].Value,16)^0xa55a1234u)!=Convert.ToUInt32(reply.Groups[2].Value,16))throw new Exception("Module challenge response mismatch");
   Say("POSITIVE CASE PASS: separate ARM32 .so loaded; JNI_OnLoad ran; fresh JNI challenge response verified.");
  }else{
   string error=mode=="missing"?"Missing module or invalid length":"Module SHA256 mismatch";
   if(!report.Contains("RESULT: OWN ARM32 MODULE LOAD FAIL")||!report.Contains(error)||report.Contains("ARM32_PLUGIN_OK"))throw new Exception("Negative case did not reject for the expected reason");
   Say("EXPECTED REJECTION PASS: "+mode);
  }
 }
 static int Main(string[] args){
  bool self=args.Contains("--self-test"),batch=args.Contains("--batch");int result=1;
  try{
   Say("Own-app ARM32 module loader test "+DateTime.Now.ToString("o"));CheckLocal();
   if(self){Say("RESULT: LOCAL FILE CHECK PASS; runtime not tested");result=0;}
   else{
    Select();Say("Install own companion APK: "+Run("-s "+Serial+" install -r \""+Path.Combine(Folder,"BS4-ARM32-Module-Test.apk")+"\"",60000).Trim());
    Test("missing");Test("corrupt");Test("positive");
    string log=Run("-s "+Serial+" logcat -d -v threadtime -s BS4ArmProbe:I *:S",15000);
    File.WriteAllText(Path.Combine(Folder,"module-logcat.txt"),log,new UTF8Encoding(false));
    Say("RESULT: OWN APP ARM32 MODULE LOADER PASS (positive + missing + corrupt)");
    Say("Scope: own APK explicitly implements module loading via System.load and JNI. This is not external process injection and does not implement loading into an unchanged game.");result=0;
   }
  }catch(Exception e){Say("ERROR: "+e.Message);Say("RESULT: TEST INCOMPLETE OR FAILED");}
  finally{
   string path=Path.Combine(Folder,self?"module-local-check.txt":"module-loader-report.txt");File.WriteAllText(path,Log.ToString(),new UTF8Encoding(false));Console.WriteLine("Saved: "+path);
   if(!self&&!batch){Console.WriteLine("Press Enter to close.");Console.ReadLine();}
  }
  return result;
 }
}
