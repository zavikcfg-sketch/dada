from pathlib import Path
import zipfile,shutil
base=Path('D:/ааааа/чичи/arm32-probe');p=base/'module-loader';out=p/'outputs'
(out/'README.txt').write_text('''Загрузчик ARM32-модуля для СОБСТВЕННОГО тестового Android-приложения.

Проверено на этом компьютере, BlueStacks 4, emulator-5556:
RESULT: OWN APP ARM32 MODULE LOADER PASS (positive + missing + corrupt)
Положительный запуск: PID 6990, JNI_OnLoad=1, nonce=90f776ee, response=35ad64da.
SHA256 модуля: d99f887ba47efbb6711cd31e44540eb7d89f292bda379b7097652ff2f89e9921
ELF32 ARM EABI5. Модуль отправляется отдельно, внутри APK его нет.

Как работает:
Windows EXE через ADB обновляет только org.example.bs4armprobe, передаёт .so
в собственную внешнюю папку приложения и запускает Activity с load_plugin=true.
Приложение проверяет зафиксированный SHA256, копирует файл во внутреннюю
папку app_probe_modules и само выполняет System.load.
JNI-метод модуля отвечает на случайное число; EXE независимо сверяет ответ.
Это явный интерфейс загрузки в собственном приложении.
Внешняя инжекция в процесс и загрузка в неизменённую игру НЕ реализованы.
Проверенное ранее внешнее чтение памяти по PID остаётся отдельным этапом.

Повторить тест: распаковать ВСЁ, оставить один BlueStacks, запустить
BS4-Own-Module-Loader.exe. Права администратора для этого EXE не требуются.
Он выполнит проверки missing, corrupt, positive; в конце оставит рабочий модуль.
Ожидаемые MODULE LOAD FAIL в missing/corrupt — результаты отрицательных тестов.
Ошибки в других местах не считаются успешным отказом.
Итог: module-loader-report.txt; подробности: module-*-report.txt, module-logcat.txt.

--self-test проверяет только локальные файлы. --batch выполняет тесты без паузы в конце.
Сборка APK требует инструментов из ../tools относительно каталога module-loader:
Zig 0.13.0, JDK17, platform25, build-tools30.0.3. Они в ZIP не включены.
C# компилируется .NET Framework 4 x64; Java/C и build.py включены.
Базовая libarmprobe.so поставляется внутри APK; её исходник также приложен.

APK использует тот же собственный пакет и тестовый ключ, версия кода повышена до 2.
Для повторного запуска старого Windows-ARM32-PID-Probe можно заменить его
BS4-ARM32-Probe.apk копией нового BS4-ARM32-Module-Test.apk с прежним именем;
формат базового отчёта и известный буфер сохранены.
''',encoding='utf-8')
shutil.copyfile(base/'src/armprobe.c',p/'src/armprobe.c')
with zipfile.ZipFile(out/'BS4-ARM32-Module-Test.apk') as z:
 assert not any('armplugin' in n for n in z.namelist()),'Plugin must not be inside APK'
archive=base/'outputs/BS4-Own-Module-Loader.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in out.iterdir():
  if f.is_file() and f.suffix!='.idsig':z.write(f,'BS4-Own-Module-Loader/'+f.name)
 for f in (p/'src').iterdir():
  if f.is_file():z.write(f,'BS4-Own-Module-Loader/src/'+f.name)
 z.write(p/'build.py','BS4-Own-Module-Loader/build.py')
 for f in (p/'build/include').iterdir():
  if f.is_file():z.write(f,'BS4-Own-Module-Loader/build/include/'+f.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;print('ZIP verified:',len(z.namelist()),'files,',archive.stat().st_size,'bytes')
print((out/'module-elf-check.txt').read_text())
