from pathlib import Path
import hashlib,struct
p=Path('D:/ааааа/чичи/arm32-probe/module-loader')
b=(p/'outputs/libarmplugin.so').read_bytes();assert b[:7]==b'\x7fELF\x01\x01\x01';assert struct.unpack_from('<H',b,18)[0]==40;assert struct.unpack_from('<I',b,36)[0]>>24==5
shoff=struct.unpack_from('<I',b,32)[0];size,num=struct.unpack_from('<HH',b,46);sections=[struct.unpack_from('<10I',b,shoff+i*size) for i in range(num)];exports=[];undefined=[]
for s in sections:
 if s[1]!=11:continue
 st=sections[s[6]];strings=b[st[4]:st[4]+st[5]]
 for i in range(s[5]//s[9]):
  name,value,_,info,other,index=struct.unpack_from('<IIIBBH',b,s[4]+i*s[9]);name=strings[name:].split(b'\0')[0].decode()
  if name:(exports if index else undefined).append(name)
assert not undefined,undefined
assert 'JNI_OnLoad' in exports and 'Java_org_example_bs4armprobe_MainActivity_pluginResult' in exports
h=hashlib.sha256(b).hexdigest();f=p/'src/MainActivity.java';f.write_text(f.read_text().replace('HASH_PLACEHOLDER',h),encoding='utf-8')
(p/'outputs/module-elf-check.txt').write_text('ELF32 ARM EABI5\nExports: '+', '.join(exports)+'\nUndefined dynamic symbols: none\nSHA256: '+h+'\n',encoding='utf-8');print(h)
