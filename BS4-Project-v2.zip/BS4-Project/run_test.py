from pathlib import Path
import subprocess,time
p=Path('D:/ааааа/чичи/arm32-probe');out=p/'outputs';adb='C:/Program Files/BlueStacks_bgp64/HD-Adb.exe';serial='emulator-5556'
def run(*args,timeout=30,check=True):
 r=subprocess.run([adb,'-s',serial,*map(str,args)],capture_output=True,timeout=timeout)
 text=(r.stdout+r.stderr).decode('utf-8',errors='replace')
 print('$ adb '+' '.join(map(str,args))+'\n'+text,flush=True)
 if check and r.returncode: raise RuntimeError(text)
 return text
transcript=[]
transcript.append(run('shell','getprop ro.product.cpu.abilist; getprop ro.dalvik.vm.native.bridge; getprop ro.build.version.sdk'))
transcript.append(run('install','-r',out/'BS4-ARM32-Probe.apk',timeout=60))
transcript.append(run('shell','am','force-stop','org.example.bs4armprobe'))
transcript.append(run('shell','rm','-f','/sdcard/Android/data/org.example.bs4armprobe/files/arm32-report.txt'))
transcript.append(run('shell','am','start','-W','-n','org.example.bs4armprobe/.MainActivity'))
report=''
for attempt in range(10):
 r=subprocess.run([adb,'-s',serial,'shell','cat','/sdcard/Android/data/org.example.bs4armprobe/files/arm32-report.txt'],capture_output=True,timeout=10)
 if r.returncode==0 and b'RESULT:' in r.stdout: report=r.stdout.decode('utf-8',errors='replace');break
 time.sleep(1)
log=run('logcat','-d','-v','threadtime','-s','BS4ArmProbe:I','*:S')
(out/'arm32-logcat.txt').write_text(log,encoding='utf-8')
(out/'install-report.txt').write_text('\n'.join(transcript),encoding='utf-8')
if report:
 (out/'arm32-report.txt').write_text(report,encoding='utf-8');print(report,flush=True)
else:
 crash=run('logcat','-b','crash','-d',check=False)
 (out/'arm32-crash.txt').write_text(crash,encoding='utf-8')
 raise RuntimeError('Own app did not save its report; inspect logcat/crash.')
