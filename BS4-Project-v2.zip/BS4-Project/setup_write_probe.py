from pathlib import Path
import shutil
base=Path('D:/ааааа/чичи/arm32-probe');p=base/'write-probe'
for d in ['src','build/classes','build/dex','build/lib/armeabi-v7a','outputs']: (p/d).mkdir(parents=True,exist_ok=True)
shutil.copyfile(base/'build/test-key.p12',p/'build/test-key.p12')
shutil.copyfile(base/'build/lib/armeabi-v7a/libarmprobe.so',p/'build/lib/armeabi-v7a/libarmprobe.so')
shutil.copyfile(base/'src/armprobe.c',p/'src/armprobe.c')
manifest=(base/'src/AndroidManifest.xml').read_text().replace('android:versionCode="1"','android:versionCode="3"').replace('android:versionName="1.0"','android:versionName="3.0"')
(p/'src/AndroidManifest.xml').write_text(manifest,encoding='utf-8')
s=(base/'src/MainActivity.java').read_text()
s=s.replace('boolean pass=false;', 'boolean pass=false;\n  long observeAddress=0;')
s=s.replace('long address=Long.parseLong(nativeResult.substring(start,start+8),16);','long address=Long.parseLong(nativeResult.substring(start,start+8),16);\n   observeAddress=address;')
s=s.replace('for(String line:r.toString().split', '''if(pass && getIntent().getBooleanExtra("observe_write",false)) {
   final long address=observeAddress;
   final File directory=getExternalFilesDir(null);
   Thread observer=new Thread(new Runnable(){public void run(){
    try {
     RandomAccessFile memory=new RandomAccessFile("/proc/self/mem","r");
     try {
      for(int sequence=1;sequence<=600;sequence++){
       byte[] data=new byte[256];memory.seek(address);memory.readFully(data);long checksum=2166136261L;
       for(byte value:data)checksum=((checksum^(value&255))*16777619L)&0xffffffffL;
       String text="PID="+Process.myPid()+"\\nsequence="+sequence+"\\nfirst="+(data[0]&255)+"\\nchecksum="+Long.toHexString(checksum)+"\\n";
       File temp=new File(directory,"arm32-observer.tmp"),target=new File(directory,"arm32-observer.txt");
       FileOutputStream output=new FileOutputStream(temp);try{output.write(text.getBytes("UTF-8"));}finally{output.close();}
       if(!temp.renameTo(target))throw new IOException("Observer report rename failed");
       Thread.sleep(200);
      }
     }finally{memory.close();}
    }catch(Throwable error){Log.e("BS4ArmProbe","Observer failed",error);}
   }},"OwnBufferObserver");
   observer.setDaemon(true);observer.start();
  }
  for(String line:r.toString().split''')
(p/'src/MainActivity.java').write_text(s,encoding='utf-8')
s=(base/'build.py').read_text().replace("root/'tools/", "root.parent/'tools/")
s=s.replace('str(a.relative_to(root)) if i>0 and isinstance(a,Path) and a.is_absolute() and a.is_relative_to(root)', 'os.path.relpath(a,root) if i>0 and isinstance(a,Path) and a.is_absolute()')
s=s.replace("b/'classes/org/example/bs4armprobe/MainActivity.class'", "*sorted((b/'classes').rglob('*.class'))")
s=s.replace('BS4-ARM32-Probe.apk','BS4-ARM32-Write-Test.apk')
(p/'build.py').write_text(s,encoding='utf-8')
