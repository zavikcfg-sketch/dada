from pathlib import Path
p=Path('D:/ааааа/чичи/arm32-probe');source=p/'host-probe/Windows-ARM32-PID-Probe.cs';s=source.read_text()
s=s.replace('const string GuestReport=', 'const string ObserverReport="/sdcard/Android/data/org.example.bs4armprobe/files/arm32-observer.txt";\n const string GuestReport=')
s=s.replace('static extern bool ReadProcessMemory(IntPtr process,IntPtr address,byte[] data,UIntPtr size,out UIntPtr read);','static extern bool ReadProcessMemory(IntPtr process,IntPtr address,byte[] data,UIntPtr size,out UIntPtr read);\n [DllImport("kernel32.dll",SetLastError=true)] static extern bool WriteProcessMemory(IntPtr process,IntPtr address,byte[] data,UIntPtr size,out UIntPtr written);')
s=s.replace('0x410,false,host','0x438,false,host').replace('OpenProcess(query + VM_READ)','OpenProcess(query + VM_READ + VM_WRITE + VM_OPERATION)').replace('query + VM_READ','query + VM_READ + VM_WRITE + VM_OPERATION')
s=s.replace('Read-only Windows process access.', 'One-byte reversible own test app buffer write.')
s=s.replace('BS4-ARM32-Probe.apk','BS4-ARM32-Write-Test.apk')
s=s.replace('Shell("am force-stop "+Package);Shell("rm -f "+GuestReport);','Shell("am force-stop "+Package);Shell("rm -f "+GuestReport+" "+ObserverReport);')
s=s.replace('Package+"/.MainActivity").Trim()', 'Package+"/.MainActivity --ez observe_write true").Trim()')
method='''  // Called only after identity, mapping and expected own-buffer checks.
  public void WriteOwnByte(ulong physical,byte expected,byte value){
   ulong descriptor;byte[] snapshot;ulong host=HostPage(physical,out descriptor,out snapshot);
   if(HRead(host,1)[0]!=expected)throw new Exception("Own byte changed before write");
   MBI region;if(VirtualQueryEx(Handle,new IntPtr((long)host),out region,(UIntPtr)Marshal.SizeOf(typeof(MBI)))==UIntPtr.Zero||(region.Protect&0xcc)==0||(region.Protect&0x101)!=0)
    throw new Exception("Own backing page is not already writable; no protection change attempted");
   if(!snapshot.SequenceEqual(HRead(descriptor,16)))throw new Exception("RAM descriptor changed before write");
   UIntPtr written;if(!WriteProcessMemory(Handle,new IntPtr((long)host),new byte[]{value},(UIntPtr)1,out written)||written.ToUInt64()!=1)
    throw new Exception("WriteProcessMemory failed Win32="+Marshal.GetLastWin32Error());
   if(!snapshot.SequenceEqual(HRead(descriptor,16))||HRead(host,1)[0]!=value)throw new Exception("Write verification failed");
  }
'''
s=s.replace('  public ulong Q(ulong p)',method+'  public ulong Q(ulong p)')
observer=''' class Observation {public int Pid,Sequence;public byte First;public uint Checksum;}
 static Observation ParseObservation(string text){
  Dictionary<string,string> d=new Dictionary<string,string>();
  foreach(string line in text.Replace("\\r","").Split('\\n')){int i=line.IndexOf('=');if(i>0)d.Add(line.Substring(0,i),line.Substring(i+1));}
  return new Observation{Pid=int.Parse(d["PID"]),Sequence=int.Parse(d["sequence"]),First=byte.Parse(d["first"]),Checksum=Convert.ToUInt32(d["checksum"],16)};
 }
 static Observation WaitObserved(int pid,uint checksum,byte first,int after){
  Stopwatch timer=Stopwatch.StartNew();string last="";
  while(timer.Elapsed.TotalSeconds<8){
   try{string text=Shell("cat "+ObserverReport);Observation o=ParseObservation(text);last=text.Trim();if(o.Pid==pid&&o.Sequence>after&&o.Checksum==checksum&&o.First==first)return o;}catch(Exception e){last=e.Message;}
   Thread.Sleep(150);
  }
  throw new Exception("Own Android observer did not confirm requested bytes: "+last);
 }
'''
s=s.replace(' static void Live(){',observer+' static void Live(){')
start=s.index('  Say("EXTERNAL ARM32 PID TEST PASS:')
end=s.index('\n }\n static byte[] Expected', start) if '\n }\n static byte[] Expected' in s[start:] else s.index('\n }\n static void Assert',start)
# Live ends immediately before Assert in the original source.
s=s[:start]+'''  Say("READ PREREQUISITE PASS: own ARM32 ELF and 256 buffer bytes matched twice via PID-derived tables.");
  byte[] expected=Expected(),changed=(byte[])expected.Clone();changed[0]^=0x5a;
  Observation baseline=WaitObserved(meta.Pid,Fnv(expected),expected[0],0);Observation modified=null;bool attempted=false,restored=false;
  try{
   CheckIdentity(ram,kernel,id,meta.Pid);
   if(CurrentOwnPid()!=meta.Pid.ToString()||Walk(ram.Q,id.Root,meta.Address)!=physical)throw new Exception("Own PID or page mapping changed before write");
   attempted=true;ram.WriteOwnByte(physical,expected[0],changed[0]);
   modified=WaitObserved(meta.Pid,Fnv(changed),changed[0],baseline.Sequence);
   Say("ANDROID WRITE CONFIRMATION: PID="+modified.Pid+" sequence="+modified.Sequence+" first="+modified.First+" checksum=0x"+modified.Checksum.ToString("x8"));
  }finally{
   if(attempted){
    try{
     CheckIdentity(ram,kernel,id,meta.Pid);
     if(CurrentOwnPid()!=meta.Pid.ToString()||Walk(ram.Q,id.Root,meta.Address)!=physical)throw new Exception("Identity/mapping changed; refused stale-address restoration");
     byte current=ram.Virtual(id.Root,meta.Address,1)[0];
     if(current==changed[0])ram.WriteOwnByte(physical,changed[0],expected[0]);
     else if(current!=expected[0])throw new Exception("Unexpected byte; refused to overwrite it");
     Observation after=WaitObserved(meta.Pid,Fnv(expected),expected[0],modified!=null?modified.Sequence:baseline.Sequence);
     if(!ram.Virtual(id.Root,meta.Address,256).SequenceEqual(expected))throw new Exception("Restored buffer differs from expected");
     Say("ANDROID RESTORE CONFIRMATION: sequence="+after.Sequence+" checksum=0x"+after.Checksum.ToString("x8"));restored=true;
    }catch(Exception e){Say("RESTORE NOT CONFIRMED: "+e.Message+". Close the own test app to discard its buffer.");throw;}
   }
  }
  if(modified==null||!restored)throw new Exception("Write/restore not fully confirmed");
  Say("RESULT: WINDOWS OWN ARM32 ONE-BYTE WRITE AND RESTORE PASS");
  Say("Scope: one fixed byte in the known buffer of own org.example.bs4armprobe only. No code bytes, hooks, context changes or injection. Exact emulator/kernel profile required.");'''+s[end:]
s=s.replace('windows-arm32-pid-report.txt','windows-arm32-write-report.txt').replace('Windows own ARM32 PID read diagnostic','Windows own ARM32 reversible byte write diagnostic')
s=s.replace('The Windows process handle requests query and read access only.','The live Windows handle requests query/read/write/operation for one reversible byte in the own test buffer.')
# The Windows-read self-test remains read only and uses an independent handle.
s=s.replace('Assert(Fnv(Expected())==0x1d655466,"independent ARM payload");','Assert(Fnv(Expected())==0x1d655466,"independent ARM payload");\n  Observation parsed=ParseObservation("PID=123\\nsequence=7\\nfirst=88\\nchecksum=1d655466\\n");Assert(parsed.Pid==123&&parsed.Sequence==7&&parsed.First==88&&parsed.Checksum==0x1d655466,"Android observer parser");')
(p/'write-probe/src/Windows-ARM32-Write-Probe.cs').write_text(s,encoding='utf-8')
