from pathlib import Path
p=Path('D:/ааааа/чичи/arm32-probe/src/MainActivity.java');s=p.read_text()
s=s.replace('r.append("Own process library mappings:\\n");','''int start=nativeResult.indexOf("buffer=0x")+9;
   long address=Long.parseLong(nativeResult.substring(start,start+8),16);
   byte[] bytes=new byte[256];
   RandomAccessFile mem=new RandomAccessFile("/proc/self/mem","r");mem.seek(address);mem.readFully(bytes);mem.close();
   long checksum=2166136261L;
   for(byte value:bytes) checksum=((checksum^(value&255))*16777619L)&0xffffffffL;
   boolean pointerPass=checksum==0x1d655466L;
   pass=pass && pointerPass;
   r.append("Independent Java read /proc/self/mem at ARM pointer: ").append(pointerPass?"PASS":"FAIL").append(" checksum=0x").append(Long.toHexString(checksum)).append('\\n');
   RandomAccessFile elf=new RandomAccessFile(getApplicationInfo().nativeLibraryDir+"/libarmprobe.so","r");
   byte[] header=new byte[20];elf.readFully(header);elf.close();
   boolean elfPass=header[0]==127 && header[1]==69 && header[2]==76 && header[3]==70 && header[4]==1 && header[5]==1 && header[18]==40 && header[19]==0;
   pass=pass && elfPass;
   r.append("Installed library ELF32 ARM header: ").append(elfPass?"PASS":"FAIL").append('\\n');
   r.append("Own process library mappings:\\n");''')
s=s.replace('catch(Throwable t) {','catch(Throwable t) {\n   pass=false;')
s=s.replace('RESULT: ARM32 EXECUTION PASS','RESULT: ARM32 EXECUTION AND OWN POINTER READ PASS').replace('RESULT: ARM32 EXECUTION FAIL','RESULT: ARM32 EXECUTION OR OWN POINTER READ FAIL')
s=s.replace('Scope: normal JNI loading in this own APK. External PID memory access and injection are not tested.','Scope: normal JNI loading and independent own-process pointer read. External PID memory access and injection are not tested.')
p.write_text(s,encoding='utf-8')
