from pathlib import Path
p=Path('D:/ааааа/чичи/arm32-probe/src/MainActivity.java')
s=p.read_text();s=s.replace('for(String line:r.toString().split', 'try { File dir=getExternalFilesDir(null); if(dir==null) throw new IOException("External files unavailable"); FileOutputStream f=new FileOutputStream(new File(dir,"arm32-report.txt")); f.write(r.toString().getBytes("UTF-8")); f.close(); } catch(Exception e){r.append("External report save error: ").append(e).append(\'\\n\');}\n  for(String line:r.toString().split')
p.write_text(s,encoding='utf-8')
p=Path('D:/ааааа/чичи/arm32-probe/src/AndroidManifest.xml');s=p.read_text(encoding='utf-8-sig').replace('android:allowBackup="false"','android:allowBackup="false" android:hardwareAccelerated="false"');p.write_text(s,encoding='utf-8')
p=Path('D:/ааааа/чичи/arm32-probe/run_test.py');s=p.read_text(encoding='utf-8-sig');s=s.replace("'shell','run-as','org.example.bs4armprobe','cat','files/arm32-report.txt'", "'shell','cat','/sdcard/Android/data/org.example.bs4armprobe/files/arm32-report.txt'")
s=s.replace("transcript.append(run('shell','am','start'", "transcript.append(run('shell','rm','-f','/sdcard/Android/data/org.example.bs4armprobe/files/arm32-report.txt'))\ntranscript.append(run('shell','am','start'")
p.write_text(s,encoding='utf-8')
