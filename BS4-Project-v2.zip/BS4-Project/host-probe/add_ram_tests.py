from pathlib import Path
p=Path('D:/ааааа/чичи/arm32-probe/host-probe/Windows-ARM32-PID-Probe.cs')
s=p.read_text(encoding='utf-8-sig')
insert=''' static void RamSelfTest(){
  IntPtr vm=Marshal.AllocHGlobal(0x2000),range=Marshal.AllocHGlobal(0xb0),node=Marshal.AllocHGlobal(0x38),chunk=Marshal.AllocHGlobal(0x3000);
  try{
   Marshal.Copy(new byte[0x2000],0,vm,0x2000);Marshal.Copy(new byte[0xb0],0,range,0xb0);Marshal.Copy(new byte[0x38],0,node,0x38);Marshal.Copy(new byte[0x3000],0,chunk,0x3000);
   Marshal.WriteInt64(vm,0x1010,range.ToInt64());Marshal.WriteInt64(vm,0x1340,node.ToInt64());
   Marshal.WriteInt64(range,0,0x800000);Marshal.WriteInt64(range,8,0x3000);Marshal.WriteInt64(range,0x28,0x802fff);
   for(int i=0;i<3;i++){Marshal.WriteInt64(range,0x80+i*16,1L<<51);Marshal.WriteInt32(range,0x88+i*16,(7<<9)+i);}
   Marshal.WriteInt32(node,0,7);Marshal.WriteInt64(node,0x30,chunk.ToInt64());
   Marshal.Copy(new byte[]{0x12,0x34,0x56,0x78},0,IntPtr.Add(chunk,4094),4);
   Ram ram=new Ram((ulong)vm.ToInt64());Assert(ram.Read(0x800ffe,4).SequenceEqual(new byte[]{0x12,0x34,0x56,0x78}),"real Windows reads through synthetic guest RAM descriptors, crossing a page");
   bool rejected=false;try{ram.Read(0x900000,1);}catch{rejected=true;}Assert(rejected,"outside-RAM rejection");
   Marshal.WriteInt32(range,0x88,8<<9);rejected=false;try{ram.Read(0x800000,1);}catch{rejected=true;}Assert(rejected,"unmapped chunk rejection");
  }finally{Marshal.FreeHGlobal(vm);Marshal.FreeHGlobal(range);Marshal.FreeHGlobal(node);Marshal.FreeHGlobal(chunk);}
 }
'''
s=s.replace(' static void SelfTest(){',insert+' static void SelfTest(){')
s=s.replace('"own ReadProcessMemory");}finally', '"own ReadProcessMemory");RamSelfTest();}finally')
s=s.replace('independent ARM bytes, ADB parser, optional own report parser.','independent ARM bytes, RAM mapper with cross-page Windows reads, bounds/unmapped rejection, ADB parser, optional own report parser.')
p.write_text(s,encoding='utf-8')
