from pathlib import Path
import zipfile,hashlib,subprocess
root=Path('D:/ааааа/чичи/arm32-probe');folder=root/'outputs/Windows-ARM32-PID-Probe'
source=root/'host-probe/Windows-ARM32-PID-Probe.cs'
s=source.read_text();s=s.replace('No Windows/guest memory writes, hooks, remote threads, or injection.', 'No writes to emulator or other Android process memory, hooks, remote threads, or injection.')
s=s.replace('Ram ram=new Ram((ulong)vm.ToInt64());Assert(', 'Say("Self-test uses a synthetic RAM map in this Windows process:");Ram ram=new Ram((ulong)vm.ToInt64());Assert(')
source.write_text(s,encoding='utf-8')
csc='C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe'
subprocess.run([csc,'/nologo','/platform:x64','/optimize+','/target:exe','/out:'+str(folder/'Windows-ARM32-PID-Probe.exe'),str(source)],check=True)
subprocess.run([str(folder/'Windows-ARM32-PID-Probe.exe'),'--self-test'],check=True)
(folder/'Windows-ARM32-PID-Probe.cs').write_bytes(source.read_bytes())
(folder/'BS4-ARM32-Probe.apk').write_bytes((root/'outputs/BS4-ARM32-Probe.apk').read_bytes())
(folder/'README.txt').write_text('''Проверка чтения ARM32-буфера своего тестового приложения из Windows по PID.

1. Распакуй ВЕСЬ ZIP в одну папку на диске D.
2. Оставь запущенным один экземпляр BlueStacks 4. Игру запускать не требуется.
3. Запусти Windows-ARM32-PID-Probe.exe. Подтверди UAC.
   При отказе в доступе: правая кнопка по EXE -> Запуск от имени администратора.
4. Дождись строки Saved и пришли windows-arm32-pid-report.txt из этой же папки.

Инструмент установит/обновит только собственный BS4-ARM32-Probe.apk,
перезапустит org.example.bs4armprobe, получит свежие PID/адрес и проверит
таблицы страниц, ELF-заголовок своей ARM32-библиотеки и 256 байт буфера.
Параметры для выбора чужого процесса не предусмотрены.

Признак полного успеха:
RESULT: WINDOWS OWN ARM32 PID READ PASS

Самопроверки НЕ подтверждают чтение живого ARM32-процесса BlueStacks.
self-test-report.txt: выполненные самопроверки чтения Windows, RAM mapper,
таблиц страниц (4 КБ, 2 МБ, 1 ГБ), адресных границ, метаданных и ожидаемых байт.
host-preflight-report.txt: из сессии помощника OpenProcess query+VM_READ
для HD-Player отклонён Windows (Win32=5). Поэтому полный тест пока не выполнен.
На компьютере проверено точное совпадение версии и SHA256 BstkVMM.dll.

Поддерживаемый профиль: BlueStacks 4.220.0.4001 и точное ядро 4.9.95,
сборка Wed Jul 29 12:42:21 IST 2020. Другая сборка должна завершиться ошибкой.
Смещения проверены по предыдущему успешному отчёту x86_64 и профилю ядра.
Новый восстановленный код ещё требует реального запуска с правами администратора.
При изменении списков/дескрипторов во время чтения инструмент сообщает ошибку;
успех при неполной проверке не выводится.

Чтение памяти Windows выполняется с QUERY_INFORMATION + VM_READ.
Инструмент не пишет в память эмулятора, не создаёт удалённых потоков,
не ставит хуков и не выполняет инжекцию. Самопроверки выделяют свои тестовые буферы.
Не используются текущий CR3 CPU или поиск шаблона проверяемого буфера.

Самопроверки вручную: Windows-ARM32-PID-Probe.exe --self-test
Проверка прав без UAC/запуска APK: Windows-ARM32-PID-Probe.exe --preflight
Исходник C# включён, build.cmd пересобирает EXE штатным .NET Framework 4 x64.
''',encoding='utf-8')
(folder/'build.cmd').write_text('@echo off\r\n"%SystemRoot%\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe" /nologo /platform:x64 /optimize+ /target:exe /out:"%~dp0Windows-ARM32-PID-Probe.exe" "%~dp0Windows-ARM32-PID-Probe.cs"\r\nexit /b %errorlevel%\r\n',encoding='ascii')
# The prior own-app report was used to test the metadata parser. Keep it clearly labelled as an example.
old=folder/'android-own-arm32-report.txt'
if old.exists():
 examples=folder/'examples';examples.mkdir(exist_ok=True)
 (examples/'previous-own-app-report.txt').write_bytes(old.read_bytes())
 old.unlink()
archive=root/'outputs/Windows-ARM32-PID-Probe.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in folder.rglob('*'):
  if f.is_file():z.write(f,'Windows-ARM32-PID-Probe/'+f.relative_to(folder).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None; print('ZIP verified:',len(z.namelist()),'files')
print('ZIP bytes:',archive.stat().st_size)
print('EXE SHA256:',hashlib.sha256((folder/'Windows-ARM32-PID-Probe.exe').read_bytes()).hexdigest())
