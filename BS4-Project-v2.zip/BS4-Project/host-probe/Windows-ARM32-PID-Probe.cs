using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading;

// Diagnostic limited to the separately installed org.example.bs4armprobe app.
// The Windows process handle requests query and read access only.
class ArmPidProbe {
 const string Package="org.example.bs4armprobe";
 const string GuestReport="/sdcard/Android/data/org.example.bs4armprobe/files/arm32-report.txt";
 const string VmmHash="b582b356a732f3896c0b7989a11de08933cf096cc9986aa2e33c8ae85ca1c32b";
 static readonly string Folder=AppDomain.CurrentDomain.BaseDirectory;
 static readonly StringBuilder Log=new StringBuilder();
 static IntPtr Handle;
 static string Adb,Serial;
 static bool Delegated;
 [StructLayout(LayoutKind.Sequential)] struct MBI {public ulong Base,AllocationBase;public uint AllocationProtect;public ushort PartitionId,Padding;public ulong Size;public uint State,Protect,Type,Padding2;}
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,int pid);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadProcessMemory(IntPtr process,IntPtr address,byte[] data,UIntPtr size,out UIntPtr read);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 [DllImport("kernel32.dll",SetLastError=true)] static extern UIntPtr VirtualQueryEx(IntPtr h,IntPtr address,out MBI info,UIntPtr size);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr h,uint flags,StringBuilder name,ref int size);
 static void Say(string s){Console.WriteLine(s);Log.AppendLine(s);}
 static string Hex(ulong n){return "0x"+n.ToString("X");}
 static ulong U64(byte[] b,int off){return BitConverter.ToUInt64(b,off);}
 static uint U32(byte[] b,int off){return BitConverter.ToUInt32(b,off);}
 static byte[] HRead(ulong addr,int n){
  if(n<0||n>1048576||addr>0x7fffffffffffUL)throw new Exception("Invalid host read bounds");
  byte[] b=new byte[n];UIntPtr got;
  if(!ReadProcessMemory(Handle,new IntPtr(unchecked((long)addr)),b,(UIntPtr)n,out got)||got.ToUInt64()!=(ulong)n)
   throw new Exception("ReadProcessMemory failed at "+Hex(addr)+" size="+n+" Win32="+Marshal.GetLastWin32Error());
  return b;
 }
 static ulong H64(ulong a){return U64(HRead(a,8),0);}
 static uint H32(ulong a){return U32(HRead(a,4),0);}
 static bool HostPtr(ulong a){return a>=0x10000&&a<0x7fffffffffffUL;}
 static bool KernelPtr(ulong a){return a>=0xffff800000000000UL;}
 static bool VmValid(ulong vm){
  try {if(!HostPtr(vm)||(vm&4095)!=0)return false;ulong uvm=H64(vm+0x18);return HostPtr(uvm)&&H32(uvm)==0x19700823&&H64(uvm+8)==vm&&H32(vm+0x38)>0&&H32(vm+0x38)<=64&&HostPtr(H64(vm+0x1010));} catch{return false;}
 }
 static ulong FindVm(){
  foreach(ulong hint in new ulong[]{0x1e600000,0x1f500000})if(VmValid(hint)){Say("Verified reciprocal VM context="+Hex(hint));return hint;}
  Stopwatch timer=Stopwatch.StartNew();ulong cursor=0;ulong total=0;
  while(cursor<0x7fffffffffffUL&&timer.Elapsed.TotalSeconds<60&&total<24UL*1024*1024*1024){
   MBI region;if(VirtualQueryEx(Handle,new IntPtr((long)cursor),out region,(UIntPtr)Marshal.SizeOf(typeof(MBI)))==UIntPtr.Zero)break;
   if(region.Size==0||region.Base+region.Size<=cursor)break;
   bool readable=region.State==0x1000&&(region.Protect&0x101)==0&&(region.Protect&0xee)!=0;
   if(readable&&region.Type==0x20000){
    for(ulong at=region.Base;at<region.Base+region.Size;){
     int size=(int)Math.Min(1048576UL,region.Base+region.Size-at);byte[] b=null;
     try{b=HRead(at,size);}catch{}
     if(b!=null){int first=(int)((4096-(at&4095))&4095);for(int i=first;i+16<=b.Length;i+=4096){
      if(U32(b,i)!=0x19700823)continue;ulong vm=U64(b,i+8);if(VmValid(vm)){Say("Verified reciprocal VM context="+Hex(vm));return vm;}
     }}
     at+=(ulong)size;total+=(ulong)size;
     if(timer.Elapsed.TotalSeconds>=60)break;
    }
   }
   cursor=region.Base+region.Size;
  }
  throw new Exception("Verified VM context not found within the bounded structural scan; no guest payload scanning was used.");
 }
 class Range {public ulong Node,Start,Size;}
 class Ram {
  public ulong Vm;List<Range> ranges=new List<Range>();Dictionary<uint,ulong> chunks=new Dictionary<uint,ulong>();
  public Ram(ulong vm){Vm=vm;Load();}
  void Load(){
   HashSet<ulong> seen=new HashSet<ulong>();ulong node=H64(Vm+0x1010);
   while(node!=0){
    if(!HostPtr(node)||!seen.Add(node)||seen.Count>2048)throw new Exception("Invalid RAM range list");
    byte[] b=HRead(node,0x30);ulong start=U64(b,0),size=U64(b,8),last=U64(b,0x28);
    if(size==0||size>64UL*1024*1024*1024||start+size-1!=last)throw new Exception("Invalid RAM range bounds");
    if((U32(b,0x24)&(1u<<22))==0)ranges.Add(new Range{Node=node,Start=start,Size=size});
    node=U64(b,0x10);
   }
   seen.Clear();Stack<ulong> todo=new Stack<ulong>();node=H64(Vm+0x1340);if(node!=0)todo.Push(node);
   while(todo.Count>0){
    node=todo.Pop();if(!HostPtr(node)||!seen.Add(node)||seen.Count>131072)throw new Exception("Invalid RAM chunk tree");
    byte[] b=HRead(node,0x38);uint id=U32(b,0);ulong host=U64(b,0x30);
    if(host!=0){if(!HostPtr(host)||chunks.ContainsKey(id))throw new Exception("Invalid RAM chunk entry");chunks.Add(id,host);}
    ulong left=U64(b,8),right=U64(b,16);if(left!=0)todo.Push(left);if(right!=0)todo.Push(right);
   }
   Say("RAM snapshot: ranges="+ranges.Count+" mapped 2 MiB chunks="+chunks.Count+". No VM locks acquired.");
   if(ranges.Count==0||chunks.Count==0)throw new Exception("Empty RAM map");
  }
  ulong HostPage(ulong physical,out ulong descriptor,out byte[] snapshot){
   foreach(Range r in ranges)if(physical>=r.Start&&physical-r.Start<r.Size){
    ulong relative=physical-r.Start;descriptor=r.Node+0x80+(relative>>12)*16;snapshot=HRead(descriptor,16);
    uint id=U32(snapshot,8);uint kind=(uint)((U64(snapshot,0)>>51)&7);
    if(kind!=1)throw new Exception("Requested physical page is not RAM: "+Hex(physical)+" type="+kind);
    ulong host;if(!chunks.TryGetValue(id>>9,out host))throw new Exception("RAM chunk not mapped: pageId="+Hex(id));
    return host+((ulong)(id&511)<<12)+(physical&4095);
   }
   throw new Exception("Guest physical address outside RAM: "+Hex(physical));
  }
  public byte[] Read(ulong physical,int n){
   if(n<0||n>1048576)throw new Exception("Invalid physical read length");byte[] result=new byte[n];int done=0;
   while(done<n){ulong a=physical+(ulong)done;int take=Math.Min(n-done,4096-(int)(a&4095));ulong descriptor;byte[] before;
    ulong host=HostPage(a,out descriptor,out before);byte[] data=HRead(host,take);
    if(!before.SequenceEqual(HRead(descriptor,16)))throw new Exception("RAM descriptor changed during read; retry with a fresh snapshot");
    Buffer.BlockCopy(data,0,result,done,take);done+=take;
   }
   return result;
  }
  public ulong Q(ulong p){return U64(Read(p,8),0);}
  public byte[] Virtual(ulong root,ulong va,int n){
   byte[] result=new byte[n];int done=0;
   while(done<n){ulong a=va+(ulong)done;int take=Math.Min(n-done,4096-(int)(a&4095));ulong pa=Walk(Q,root,a);byte[] b=Read(pa,take);Buffer.BlockCopy(b,0,result,done,take);done+=take;}
   return result;
  }
  public ulong K64(ulong root,ulong va){return U64(Virtual(root,va,8),0);}
  public uint K32(ulong root,ulong va){return U32(Virtual(root,va,4),0);}
 }
 static ulong Walk(Func<ulong,ulong> read,ulong root,ulong va){
  ulong high=va>>48;bool sign=(va&(1UL<<47))!=0;
  if(high!=(sign?0xffffUL:0))throw new Exception("Noncanonical x86_64 process address: "+Hex(va));
  ulong table=root&0x000ffffffffff000UL;
  if(table==0)throw new Exception("Empty process page table");
  int[] shifts={39,30,21,12};
  for(int level=0;level<4;level++){
   ulong e=read(table+((va>>shifts[level])&511)*8);
   if((e&1)==0)throw new Exception("Page-table entry not present at level "+level+" for "+Hex(va));
   if((e&128)!=0&&level==1)return (e&0x000fffffc0000000UL)|(va&0x3fffffffUL);
   if((e&128)!=0&&level==2)return (e&0x000fffffffe00000UL)|(va&0x1fffffUL);
   if((e&128)!=0&&level==0)throw new Exception("Invalid large page at PML4");
   table=e&0x000ffffffffff000UL;
  }
  return table|(va&4095);
 }
 static string Command(string file,string args,int timeout){
  ProcessStartInfo info=new ProcessStartInfo(file,args){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};
  StringBuilder output=new StringBuilder(),error=new StringBuilder();
  using(Process p=new Process()){
   p.StartInfo=info;p.OutputDataReceived+=(s,e)=>{if(e.Data!=null)lock(output)output.AppendLine(e.Data);};p.ErrorDataReceived+=(s,e)=>{if(e.Data!=null)lock(error)error.AppendLine(e.Data);};
   p.Start();p.BeginOutputReadLine();p.BeginErrorReadLine();
   if(!p.WaitForExit(timeout)){try{p.Kill();}catch{}throw new Exception("ADB timeout: "+args);}
   p.WaitForExit();if(p.ExitCode!=0)throw new Exception("ADB command failed: "+args+" : "+error+output);
   return output.ToString();
  }
 }
 static string Shell(string command){return Command(Adb,"-s "+Serial+" shell "+command,10000).Replace("\r","");}
 static void SelectAdb(){
  string[] paths={@"C:\Program Files\BlueStacks_bgp64\HD-Adb.exe",@"C:\Program Files\BlueStacks\HD-Adb.exe"};
  Adb=paths.FirstOrDefault(File.Exists);if(Adb==null)throw new Exception("BlueStacks HD-Adb.exe was not found");
  List<string> live=new List<string>();
  foreach(string serial in ParseDevices(Command(Adb,"devices",10000))){
   try{string id=Command(Adb,"-s "+serial+" shell id",3000);if(!id.Contains("uid="))continue;live.Add(serial);Say("Responding ADB device: "+serial);}catch(Exception e){Say("Skipping ADB device "+serial+": "+e.Message);}
  }
  if(live.Count!=1)throw new Exception("Expected exactly one responding Android device; found "+live.Count+". Close other emulator instances and retry.");
  Serial=live[0];
 }
 static IEnumerable<string> ParseDevices(string text){
  foreach(string line in text.Split('\n')){Match m=Regex.Match(line.Trim(),@"^([A-Za-z0-9._:-]+)\s+device$");if(m.Success)yield return m.Groups[1].Value;}
 }
 class Meta {public int Pid;public ulong Address,Elf;}
 static Meta ParseReport(string text){
  text=text.Replace("\r","");
  if(!text.Contains("RESULT: ARM32 EXECUTION AND OWN POINTER READ PASS"))throw new Exception("Own Android ARM32 test did not pass");
  Match pid=Regex.Match(text,@"^PID=(\d+)$",RegexOptions.Multiline),buf=Regex.Match(text,@"ARM32_NATIVE_OK pointer_bytes=4 buffer=0x([0-9a-fA-F]{8}) checksum=0x1d655466");
  if(!pid.Success||!buf.Success)throw new Exception("Invalid own-app metadata");
  Meta meta=new Meta{Pid=int.Parse(pid.Groups[1].Value),Address=Convert.ToUInt64(buf.Groups[1].Value,16)};bool contains=false;
  foreach(Match m in Regex.Matches(text,@"^([0-9a-f]+)-([0-9a-f]+)\s+([rwxps-]+)\s+([0-9a-f]+)\s+\S+\s+\d+\s+(.*/libarmprobe\.so)$",RegexOptions.Multiline)){
   ulong start=Convert.ToUInt64(m.Groups[1].Value,16),end=Convert.ToUInt64(m.Groups[2].Value,16),offset=Convert.ToUInt64(m.Groups[4].Value,16);
   if(offset==0&&m.Groups[3].Value.StartsWith("r"))meta.Elf=start;
   if(meta.Address>=start&&meta.Address+256<=end&&m.Groups[3].Value.StartsWith("rw"))contains=true;
  }
  if(meta.Pid<1||meta.Elf==0||!contains||meta.Address>0xffffffffUL-256)throw new Exception("Own ARM buffer is not inside the reported library mapping");
  return meta;
 }
 static string CurrentOwnPid(){return Shell("pidof "+Package).Trim();}
 static string LaunchOwnApp(){
  string apk=Path.Combine(Folder,"BS4-ARM32-Probe.apk");
  if(File.Exists(apk))Say("Install own test APK: "+Command(Adb,"-s "+Serial+" install -r \""+apk+"\"",60000).Trim());
  Shell("am force-stop "+Package);Shell("rm -f "+GuestReport);
  Say(Shell("am start -W -n "+Package+"/.MainActivity").Trim());
  string text=null;Stopwatch clock=Stopwatch.StartNew();
  while(clock.Elapsed.TotalSeconds<15){try{string candidate=Shell("cat "+GuestReport);if(candidate.Contains("RESULT:")){text=candidate;break;}}catch{}Thread.Sleep(500);}
  if(text==null)throw new Exception("Own APK did not publish its report. No PID memory read attempted.");
  File.WriteAllText(Path.Combine(Folder,"android-own-arm32-report.txt"),text,new UTF8Encoding(false));return text;
 }
 static string ImagePath(int pid){
  IntPtr h=OpenProcess(0x1000,false,pid);if(h==IntPtr.Zero)throw new Exception("Cannot query emulator path");
  try{StringBuilder s=new StringBuilder(32768);int n=s.Capacity;if(!QueryFullProcessImageName(h,0,s,ref n))throw new Exception("Cannot query emulator executable");return s.ToString();}finally{CloseHandle(h);}
 }
 static void VerifyHost(out int pid){
  Process[] list=Process.GetProcessesByName("HD-Player");if(list.Length!=1)throw new Exception("Expected exactly one HD-Player process, found "+list.Length);
  pid=list[0].Id;string path=ImagePath(pid);string version=FileVersionInfo.GetVersionInfo(path).FileVersion;
  Say("Host PID="+pid+" version="+version+" path="+path);
  if(version!="4.220.0.4001")throw new Exception("Unsupported BlueStacks build; offsets have not been verified for "+version);
  string dll=Path.Combine(Path.GetDirectoryName(path),"BstkVMM.dll");string hash;
  using(SHA256 sha=SHA256.Create())using(FileStream stream=File.OpenRead(dll))hash=BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
  if(hash!=VmmHash)throw new Exception("BstkVMM.dll does not match the verified profile");Say("BstkVMM.dll SHA256 matches verified profile.");
 }
 static ulong Align4(ulong n){return (n+3)&~3UL;}
 static ulong KernelRoot(Ram ram,out ulong slide){
  string value=Shell("cat /sys/kernel/vmcoreinfo").Trim();string[] fields=value.Split(new char[]{' ','\t'},StringSplitOptions.RemoveEmptyEntries);
  if(fields.Length!=2)throw new Exception("Invalid VMCOREINFO location");
  ulong note=Convert.ToUInt64(fields[0].Replace("0x",""),16);int size=Convert.ToInt32(fields[1],16);
  if(size<16||size>65536||note<0x1e80b40)throw new Exception("Unexpected VMCOREINFO bounds");
  byte[] b=ram.Read(note,size);uint names=U32(b,0),desc=U32(b,4);ulong at=12+Align4(names);
  if(names>64||desc<1||at+desc>(ulong)b.Length)throw new Exception("Invalid VMCOREINFO ELF note");
  string name=Encoding.ASCII.GetString(b,12,(int)names).TrimEnd('\0');if(name!="VMCOREINFO")throw new Exception("Unexpected ELF note name: "+name);
  string text=Encoding.ASCII.GetString(b,(int)at,(int)desc);
  if(!Regex.IsMatch(text,@"^OSRELEASE=4\.9\.95$",RegexOptions.Multiline))throw new Exception("Kernel profile release mismatch");
  Match st=Regex.Match(text,@"^SYMBOL\(_stext\)=([0-9a-fA-F]+)$",RegexOptions.Multiline);if(!st.Success)throw new Exception("VMCOREINFO does not contain _stext");
  ulong actual=Convert.ToUInt64(st.Groups[1].Value,16);if(actual<0xffffffff810002b8UL)throw new Exception("Unexpected kernel virtual slide");
  slide=actual-0xffffffff810002b8UL;ulong physicalSlide=note-0x1e80b40UL;
  if(slide>0x40000000UL||physicalSlide>0x40000000UL)throw new Exception("Kernel slide outside supported bounds");
  ulong root=0x1c0a000UL+physicalSlide;
  string expected="Linux version 4.9.95 (build@Build2) (gcc version 4.6 20120106 (prerelease) (GCC) ) #1 SMP PREEMPT Wed Jul 29 12:42:21 IST 2020\n";
  string actualBanner=Encoding.ASCII.GetString(ram.Virtual(root,0xffffffff818000c0UL+slide,expected.Length));
  if(actualBanner!=expected)throw new Exception("Live kernel banner does not match the exact profile");
  Say("Live kernel profile matched. Root="+Hex(root)+" virtual slide="+Hex(slide)+" physical slide="+Hex(physicalSlide));return root;
 }
 class Identity {public ulong Task,PidStruct,Mm,Pgd,Root;}
 static Identity FindOwnTask(Ram ram,ulong kernel,ulong slide,int pid){
  ulong head=0xffffffff81c11500UL+slide+0x418UL,previous=head,node=ram.K64(kernel,head);HashSet<ulong> seen=new HashSet<ulong>();Stopwatch clock=Stopwatch.StartNew();
  while(node!=head){
   if(!KernelPtr(node)||!seen.Add(node)||seen.Count>65536||clock.Elapsed.TotalSeconds>25)throw new Exception("Task list bounds/consistency check failed");
   if(ram.K64(kernel,node+8)!=previous)throw new Exception("Task list changed; retry the diagnostic");
   ulong task=node-0x418,ps=ram.K64(kernel,task+0x588);
   if(KernelPtr(ps)&&ram.K32(kernel,ps+0x30)==(uint)pid){
    ulong mm=ram.K64(kernel,task+0x468);if(!KernelPtr(mm))throw new Exception("Own app has no valid mm");
    ulong pgd=ram.K64(kernel,mm+0x40);if(!KernelPtr(pgd)||(pgd&4095)!=0)throw new Exception("Invalid own-app PGD pointer");
    ulong root=Walk(ram.Q,kernel,pgd);if((root&4095)!=0)throw new Exception("Unaligned own-app process root");
    string comm=Encoding.ASCII.GetString(ram.Virtual(kernel,task+0x6d8,16)).Split('\0')[0];
    Say("Own PID lookup: PID="+pid+" comm="+comm+" task="+Hex(task)+" mm="+Hex(mm)+" pgd="+Hex(pgd)+" process root="+Hex(root)+" scanned="+seen.Count);
    return new Identity{Task=task,PidStruct=ps,Mm=mm,Pgd=pgd,Root=root};
   }
   previous=node;node=ram.K64(kernel,node);
  }
  throw new Exception("Own app PID not found in the verified root-namespace task list");
 }
 static void CheckIdentity(Ram ram,ulong kernel,Identity id,int pid){
  if(ram.K64(kernel,id.Task+0x588)!=id.PidStruct||ram.K32(kernel,id.PidStruct+0x30)!=(uint)pid||ram.K64(kernel,id.Task+0x468)!=id.Mm||ram.K64(kernel,id.Mm+0x40)!=id.Pgd||Walk(ram.Q,kernel,id.Pgd)!=id.Root)
   throw new Exception("Own process identity/page tables changed during diagnostic");
 }
 static byte[] Expected(){byte[] result=new byte[256];uint seed=0x13579bdf;for(int i=0;i<result.Length;i++){seed=unchecked(seed*1664525u+1013904223u);result[i]=(byte)(seed>>24);}return result;}
 static uint Fnv(byte[] b){uint h=2166136261;foreach(byte n in b)h=unchecked((h^n)*16777619);return h;}
 static void Live(){
  int host;VerifyHost(out host);Handle=OpenProcess(0x410,false,host);
  if(Handle==IntPtr.Zero)throw new Exception("OpenProcess(query + VM_READ) denied, Win32="+Marshal.GetLastWin32Error()+". Run the EXE as administrator. No process protection bypass is attempted.");
  SelectAdb();string text=LaunchOwnApp();Meta meta=ParseReport(text);
  if(CurrentOwnPid()!=meta.Pid.ToString())throw new Exception("Published PID does not match the current own test app");
  Say("Target is fixed to own package "+Package+", PID="+meta.Pid+" ARM buffer="+Hex(meta.Address));
  ulong vm=FindVm();Ram ram=new Ram(vm);ulong slide;ulong kernel=KernelRoot(ram,out slide);Identity id=FindOwnTask(ram,kernel,slide,meta.Pid);
  CheckIdentity(ram,kernel,id,meta.Pid);
  byte[] elf=ram.Virtual(id.Root,meta.Elf,40);
  if(elf[0]!=127||elf[1]!=69||elf[2]!=76||elf[3]!=70||elf[4]!=1||elf[5]!=1||BitConverter.ToUInt16(elf,18)!=40||U32(elf,36)>>24!=5)
   throw new Exception("External virtual read did not find ELF32 ARM EABI5 at the own library base");
  Say("External read: own mapped library ELF32 ARM EABI5 verified at "+Hex(meta.Elf));
  ulong physical=Walk(ram.Q,id.Root,meta.Address);byte[] first=ram.Virtual(id.Root,meta.Address,256);Thread.Sleep(250);byte[] second=ram.Virtual(id.Root,meta.Address,256);
  if(!first.SequenceEqual(Expected())||!second.SequenceEqual(first)||Fnv(first)!=0x1d655466)throw new Exception("External ARM buffer mismatch");
  CheckIdentity(ram,kernel,id,meta.Pid);
  if(CurrentOwnPid()!=meta.Pid.ToString()||ParseReport(Shell("cat "+GuestReport)).Address!=meta.Address)throw new Exception("Own app restarted or published a different address");
  Say("EXTERNAL ARM32 PID TEST PASS: VA="+Hex(meta.Address)+" -> PID-derived root="+Hex(id.Root)+" -> guest physical="+Hex(physical));
  Say("All 256 bytes matched independently generated expected bytes, twice. FNV-1a=0x"+Fnv(first).ToString("x8"));
  Say("RESULT: WINDOWS OWN ARM32 PID READ PASS");
  Say("Scope: only this own test APK and the exact verified emulator/kernel builds. No writes to emulator or other Android process memory, hooks, remote threads, or injection. No current CPU CR3 sampling or payload pattern scanning.");
 }
 static void Assert(bool b,string m){if(!b)throw new Exception("Self-test failed: "+m);}
 static void RamSelfTest(){
  IntPtr vm=Marshal.AllocHGlobal(0x2000),range=Marshal.AllocHGlobal(0xb0),node=Marshal.AllocHGlobal(0x38),chunk=Marshal.AllocHGlobal(0x3000);
  try{
   Marshal.Copy(new byte[0x2000],0,vm,0x2000);Marshal.Copy(new byte[0xb0],0,range,0xb0);Marshal.Copy(new byte[0x38],0,node,0x38);Marshal.Copy(new byte[0x3000],0,chunk,0x3000);
   Marshal.WriteInt64(vm,0x1010,range.ToInt64());Marshal.WriteInt64(vm,0x1340,node.ToInt64());
   Marshal.WriteInt64(range,0,0x800000);Marshal.WriteInt64(range,8,0x3000);Marshal.WriteInt64(range,0x28,0x802fff);
   for(int i=0;i<3;i++){Marshal.WriteInt64(range,0x80+i*16,1L<<51);Marshal.WriteInt32(range,0x88+i*16,(7<<9)+i);}
   Marshal.WriteInt32(node,0,7);Marshal.WriteInt64(node,0x30,chunk.ToInt64());
   Marshal.Copy(new byte[]{0x12,0x34,0x56,0x78},0,IntPtr.Add(chunk,4094),4);
   Say("Self-test uses a synthetic RAM map in this Windows process:");Ram ram=new Ram((ulong)vm.ToInt64());Assert(ram.Read(0x800ffe,4).SequenceEqual(new byte[]{0x12,0x34,0x56,0x78}),"real Windows reads through synthetic guest RAM descriptors, crossing a page");
   bool rejected=false;try{ram.Read(0x900000,1);}catch{rejected=true;}Assert(rejected,"outside-RAM rejection");
   Marshal.WriteInt32(range,0x88,8<<9);rejected=false;try{ram.Read(0x800000,1);}catch{rejected=true;}Assert(rejected,"unmapped chunk rejection");
  }finally{Marshal.FreeHGlobal(vm);Marshal.FreeHGlobal(range);Marshal.FreeHGlobal(node);Marshal.FreeHGlobal(chunk);}
 }
 static void SelfTest(){
  Assert(Marshal.SizeOf(typeof(MBI))==48,"Windows x64 MEMORY_BASIC_INFORMATION layout");
  Dictionary<ulong,ulong> t=new Dictionary<ulong,ulong>();Func<ulong,ulong> read=a=>t.ContainsKey(a)?t[a]:0;
  t[0x1000]=0x2001;t[0x2000]=0x3001;t[0x3000]=0x4001;t[0x4008]=0x9001;
  Assert(Walk(read,0x1000,0x1234)==0x9234,"4 KiB walk");
  t[0x3000]=0x200081;Assert(Walk(read,0x1000,0x1234)==0x201234,"2 MiB walk");
  t[0x2000]=0x40000081;Assert(Walk(read,0x1000,0x1234)==0x40001234,"1 GiB walk");
  bool rejected=false;try{Walk(read,0x1000,0x0000800000000000);}catch{rejected=true;}Assert(rejected,"noncanonical rejection");
  rejected=false;try{Walk(read,0x1000,1UL<<39);}catch{rejected=true;}Assert(rejected,"missing-entry rejection");
  t.Clear();ulong high=0xffff880000001234UL;t[0x1000+((high>>39)&511)*8]=0x2001;t[0x2000]=0x3001;t[0x3000]=0x4001;t[0x4008]=0x9001;
  Assert(Walk(read,0x1000,high)==0x9234,"kernel-half canonical walk");
  Assert(Fnv(Expected())==0x1d655466,"independent ARM payload");
  Assert(ParseDevices("List of devices attached\nemulator-5556\tdevice\nx offline\ny unauthorized\n").SequenceEqual(new string[]{"emulator-5556"}),"ADB state filtering");
  IntPtr memory=Marshal.AllocHGlobal(8);try{Marshal.WriteInt64(memory,0x12345678);Handle=OpenProcess(0x410,false,Process.GetCurrentProcess().Id);Assert(Handle!=IntPtr.Zero,"own Windows query/read handle");Assert(H64((ulong)memory.ToInt64())==0x12345678,"own ReadProcessMemory");RamSelfTest();}finally{if(Handle!=IntPtr.Zero){CloseHandle(Handle);Handle=IntPtr.Zero;}Marshal.FreeHGlobal(memory);}
  string own=Path.Combine(Folder,"android-own-arm32-report.txt");if(File.Exists(own)){Meta m=ParseReport(File.ReadAllText(own));Assert(m.Address!=0,"actual own report parser");}
  Say("Self-tests PASS: Windows read, 4 KiB/2 MiB/1 GiB walks, missing-entry and noncanonical rejection, kernel-half walk, independent ARM bytes, RAM mapper with cross-page Windows reads, bounds/unmapped rejection, ADB parser, optional own report parser. These are not live external ARM32 tests.");
 }
 static int Main(string[] args){
  bool test=args.Contains("--self-test"),preflight=args.Contains("--preflight");int exit=1;
  try{
   if(!test&&!preflight&&!new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator)){
    ProcessStartInfo start=new ProcessStartInfo(Process.GetCurrentProcess().MainModule.FileName){UseShellExecute=true,Verb="runas",WorkingDirectory=Folder};
    Process.Start(start);Delegated=true;return 0;
   }
   Say("Windows own ARM32 PID read diagnostic; "+DateTime.Now.ToString("o"));
   SelfTest();
   if(test){exit=0;return exit;}
   if(preflight){int host;VerifyHost(out host);Handle=OpenProcess(0x410,false,host);if(Handle==IntPtr.Zero)throw new Exception("Preflight: Windows query + VM_READ denied (Win32="+Marshal.GetLastWin32Error()+"). Full live validation needs the user to run the EXE with administrator rights.");Say("Preflight: Windows query + VM_READ permitted.");exit=0;return exit;}
   Live();exit=0;
  }catch(Exception e){Say("ERROR: "+e.Message);Say("RESULT: "+(test?"SELF-TEST FAIL":preflight?"PREFLIGHT INCOMPLETE":"LIVE TEST INCOMPLETE; NO PASS CLAIM"));}
  finally{
   if(Handle!=IntPtr.Zero)CloseHandle(Handle);
   if(!Delegated){string name=test?"self-test-report.txt":preflight?"host-preflight-report.txt":"windows-arm32-pid-report.txt";try{File.WriteAllText(Path.Combine(Folder,name),Log.ToString(),new UTF8Encoding(false));Console.WriteLine("Saved: "+Path.Combine(Folder,name));}catch(Exception e){Console.WriteLine("Report save failed: "+e.Message);}
    if(!test&&!preflight){Console.WriteLine("Press Enter to close.");Console.ReadLine();}}
  }
  return exit;
 }
}
