@echo off
set "BS4PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%BS4PY%" (
  "%BS4PY%" "%~dp0own_jdwp_load.py"
) else (
  python "%~dp0own_jdwp_load.py"
)
pause
