"""External JDWP load test, restricted to our debuggable org.example.bs4armprobe APK."""
import socket, struct, subprocess, time, hashlib, json, sys, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PACKAGE='org.example.bs4armprobe'
ADB=Path(r'C:\Program Files\BlueStacks_bgp64\HD-Adb.exe')
SERIAL='emulator-5556'
REMOTE='/data/local/tmp/bs4-own-external.so'
REPORT='/sdcard/Android/data/org.example.bs4armprobe/files/external-module-report.txt'
LOG=[]
def log(s):
 print(s,flush=True);LOG.append(str(s))
def adb(*args,timeout=15):
 r=subprocess.run([str(ADB),'-s',SERIAL,*map(str,args)],capture_output=True,timeout=timeout)
 text=(r.stdout+r.stderr).decode('utf-8',errors='replace').replace('\r','')
 if r.returncode:raise RuntimeError('ADB '+str(args)+': '+text)
 return text

def i32(n):return struct.pack('>I',n)
def string(s):
 b=s.encode('utf-8');return i32(len(b))+b
class Reader:
 def __init__(self,data):self.b=data;self.p=0
 def take(self,n):
  if n<0 or self.p+n>len(self.b):raise ValueError('Truncated JDWP data')
  b=self.b[self.p:self.p+n];self.p+=n;return b
 def number(self,n=4):return int.from_bytes(self.take(n),'big')
 def text(self):return self.take(self.number()).decode('utf-8')
class JDWP:
 def __init__(self,port):
  self.sock=socket.create_connection(('127.0.0.1',port),timeout=15);self.sock.settimeout(15);self.counter=0;self.events=[]
  self.sock.sendall(b'JDWP-Handshake')
  if self.exact(14)!=b'JDWP-Handshake':raise RuntimeError('JDWP handshake mismatch')
  sizes=struct.unpack('>5I',self.command(1,7));self.field,self.method,self.object,self.ref,self.frame=sizes
  if any(n not in (4,8) for n in sizes):raise RuntimeError('Unsupported JDWP ID size')
  log('JDWP ID sizes='+str(sizes))
 def exact(self,n):
  b=b''
  while len(b)<n:
   chunk=self.sock.recv(n-len(b))
   if not chunk:raise EOFError('JDWP closed')
   b+=chunk
  return b
 def packet(self):
  head=self.exact(11);length,ident,flags=struct.unpack('>IIB',head[:9])
  if length<11 or length>16*1024*1024:raise RuntimeError('JDWP packet bounds')
  return ident,flags,head[9:],self.exact(length-11)
 def command(self,group,command,data=b''):
  self.counter+=1;ident=self.counter
  self.sock.sendall(struct.pack('>IIBBB',11+len(data),ident,0,group,command)+data)
  while True:
   rid,flags,tail,body=self.packet()
   if flags&128:
    if rid!=ident:raise RuntimeError('Unexpected JDWP reply ID')
    error=int.from_bytes(tail,'big')
    if error:raise RuntimeError(f'JDWP command {group}:{command} error={error}')
    return body
   if tail!=bytes([64,100]):raise RuntimeError('Unexpected VM command')
   self.events.append(body)
 def ident(self,value,kind='object'):return value.to_bytes(getattr(self,kind),'big')
 def class_id(self,signature):
  r=Reader(self.command(1,2,string(signature)));count=r.number()
  if count!=1:raise RuntimeError('Expected one loaded class '+signature+', found '+str(count))
  r.number(1);return r.number(self.ref)
 def methods(self,clazz):
  r=Reader(self.command(2,5,self.ident(clazz,'ref')));result=[]
  for _ in range(r.number()):result.append((r.number(self.method),r.text(),r.text(),r.number()))
  return result
 def value(self,reader):
  tag=reader.number(1)
  if tag==ord('V'):return None
  if tag in map(ord,'[Lstglc'):return reader.number(self.object)
  widths={ord('B'):1,ord('Z'):1,ord('C'):2,ord('S'):2,ord('I'):4,ord('F'):4,ord('J'):8,ord('D'):8}
  return reader.number(widths[tag])
 def invoke(self,clazz,thread,method,args=(),receiver=None):
  prefix=(self.ident(receiver) if receiver is not None else b'')
  prefix+=self.ident(thread)+self.ident(clazz,'ref') if receiver is not None else self.ident(clazz,'ref')+self.ident(thread)
  body=prefix+self.ident(method,'method')+i32(len(args))
  for tag,value in args:body+=tag.encode()+self.ident(value)
  r=Reader(self.command(9 if receiver is not None else 3,6 if receiver is not None else 3,body+i32(0)))
  result=self.value(r);exception=self.value(r)
  if exception:raise RuntimeError('Target method raised Java exception object '+hex(exception))
  return result
 def entry_event(self,request):
  deadline=time.monotonic()+15
  while time.monotonic()<deadline:
   if self.events:body=self.events.pop(0)
   else:
    _,flags,tail,body=self.packet()
    if flags&128 or tail!=bytes([64,100]):raise RuntimeError('Unexpected packet while awaiting own event')
   r=Reader(body);policy=r.number(1)
   for _ in range(r.number()):
    kind=r.number(1);rid=r.number()
    if kind==90:r.number(self.object);continue
    if kind==40:
     thread=r.number(self.object);r.number(1);clazz=r.number(self.ref);r.number(self.method);r.number(8)
     if rid==request and policy==2:return thread,clazz
    else:raise RuntimeError('Unexpected event kind '+str(kind))
  raise TimeoutError('Own method-entry event did not arrive')
 def close(self):
  try:self.command(1,6)
  finally:self.sock.close()

def run():
 module=ROOT/'outputs/libownexternal.so'
 data=module.read_bytes()
 assert data[:7]==b'\x7fELF\x01\x01\x01' and struct.unpack_from('<H',data,18)[0]==40
 if hashlib.sha256(data).hexdigest()!='5334aa2ea95cbd6a2ef44cce4dc6d48136ab97277911894261b66d296b4c120f':raise RuntimeError('Unexpected own test module SHA256')
 package=adb('shell','dumpsys package '+PACKAGE)
 if 'DEBUGGABLE' not in package:raise RuntimeError('Own APK is not debuggable')
 old=adb('shell','settings get global debug_app').strip()
 if old not in ('','null'):raise RuntimeError('Another app already configured for debugging: '+old)
 log('Own module SHA256='+hashlib.sha256(data).hexdigest())
 apk=ROOT.parent/'write-probe/outputs/BS4-ARM32-Write-Test.apk'
 with zipfile.ZipFile(apk) as z:
  if any('ownexternal' in name for name in z.namelist()):raise RuntimeError('External module unexpectedly packaged inside APK')
 apk_hash=hashlib.sha256(apk.read_bytes()).hexdigest();log('Unmodified own APK SHA256='+apk_hash)
 adb('push',module,REMOTE);adb('shell','chmod 644 '+REMOTE)
 adb('shell','mkdir -p /sdcard/Android/data/'+PACKAGE+'/files')
 adb('shell','rm -f '+REPORT)
 jdwp=None;port=None
 try:
  adb('shell','am force-stop '+PACKAGE)
  adb('shell','am set-debug-app -w '+PACKAGE)
  adb('shell','am start -n '+PACKAGE+'/.MainActivity')
  pid=''
  for _ in range(20):
   try:pid=adb('shell','pidof '+PACKAGE).strip()
   except RuntimeError:pid=''
   if pid.isdigit():break
   time.sleep(.15)
  if not pid.isdigit():raise RuntimeError('Own PID unavailable')
  with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
  adb('forward','tcp:'+str(port),'jdwp:'+pid)
  log('Own PID='+pid+'; loopback JDWP port='+str(port))
  jdwp=JDWP(port);jdwp.command(1,8)
  # One event, scoped to our exact class; suspend on event for legal JDWP method invocation.
  modifiers=b'\x05'+string(PACKAGE+'.MainActivity')+b'\x01'+i32(1)
  request=int.from_bytes(jdwp.command(15,1,bytes([40,2])+i32(2)+modifiers),'big')
  jdwp.command(1,9)
  thread,clazz=jdwp.entry_event(request)
  log('Own method entry captured; thread='+hex(thread))
  loader=int.from_bytes(jdwp.command(2,2,jdwp.ident(clazz,'ref')),'big')
  class_object=int.from_bytes(jdwp.command(2,11,jdwp.ident(clazz,'ref')),'big')
  runtime=jdwp.class_id('Ljava/lang/Runtime;');methods=jdwp.methods(runtime)
  for _,name,sig,_ in methods:
   if 'load' in name.lower():log('Runtime method: '+name+sig)
  get=next(x[0] for x in methods if x[1:3]==('getRuntime','()Ljava/lang/Runtime;'))
  instance=jdwp.invoke(runtime,thread,get)
  path=int.from_bytes(jdwp.command(1,11,string(REMOTE)),'big')
  candidates=[('load0','(Ljava/lang/Class;Ljava/lang/String;)V',[('c',class_object),('s',path)]),('load0','(Ljava/lang/ClassLoader;Ljava/lang/String;)V',[('l',loader),('s',path)]),('load','(Ljava/lang/String;Ljava/lang/ClassLoader;)V',[('s',path),('l',loader)])]
  chosen=next(((m[0],args,name,sig) for name,sig,args in candidates for m in methods if m[1:3]==(name,sig)),None)
  if chosen is None:raise RuntimeError('Supported Runtime load wrapper not found; no arbitrary fallback')
  method,args,name,sig=chosen;log('Invoke own Runtime.'+name+sig)
  jdwp.invoke(runtime,thread,method,args,instance)
  jdwp.close();jdwp=None
  text=adb('shell','cat '+REPORT)
  if 'EXTERNAL_ARM32_JNI_ONLOAD_PASS' not in text or ('PID='+pid+'\n') not in text:raise RuntimeError('External module confirmation missing: '+text)
  log(text.strip());log('RESULT: OWN DEBUGGABLE APK EXTERNAL ARM32 LOAD PASS')
  log('Scope: standard JDWP attached to our debuggable APK; no game APK or process modified.')
 finally:
  if jdwp is not None:
   try:jdwp.close()
   except Exception as e:log('Detach: '+str(e))
  adb('shell','am clear-debug-app')
  if port is not None:adb('forward','--remove','tcp:'+str(port))
  adb('shell','rm -f '+REMOTE)
 

if __name__=='__main__':
 code=1
 try:run();code=0
 except Exception as e:log('ERROR: '+repr(e));log('RESULT: EXTERNAL LOAD INCOMPLETE')
 finally:(ROOT/'outputs/external-load-report.txt').write_text('\n'.join(LOG)+'\n',encoding='utf-8')
 sys.exit(code)
