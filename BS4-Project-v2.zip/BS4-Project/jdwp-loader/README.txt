Внешняя загрузка ARM32-модуля через стандартный JDWP в собственный DEBUGGABLE APK.

Подтверждён запуск: PID 8533, JNI_OnLoad, pointer_bytes=4.
Отчёт: outputs/external-load-report.txt.
APK версии 3 использован без изменения. В APK отсутствует внешний модуль.
Код C в src/external_module.c создаёт подтверждение из JNI_OnLoad.
Python-клиент вызывает Runtime.load0 через штатный отладчик.
Цель и модуль зафиксированы; произвольный PID/пакет не принимаются.

Запуск: оставить BlueStacks открытым, открыть run.cmd.
Нужен Python 3.9+; run.cmd сначала использует установленный Python из Codex.
Используется установленный org.example.bs4armprobe версии 3 (DEBUGGABLE).
При необходимости установить write-probe/outputs/BS4-ARM32-Write-Test.apk.
Загрузчик перезапускает только собственный пакет, временно включает ожидание
отладчика, использует локальный ADB forward, затем отключает отладку и forward.
Чужая активная настройка debug_app вызывает отказ; она не перезаписывается.

Игровая инжекция в com.axlebolt.standoff2 не реализована. Этот APK не DEBUGGABLE.
Другие процессы этот загрузчик не принимает.

Справочник протокола:
https://docs.oracle.com/en/java/javase/17/docs/specs/jdwp/jdwp-protocol.html
