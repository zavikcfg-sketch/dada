#include <jni.h>
static unsigned append(char *s,unsigned p,const char *v){while(*v)s[p++]=*v++;return p;}
static unsigned decimal(char *s,unsigned p,unsigned v){char t[16];unsigned n=0;do{t[n++]='0'+v%10;v/=10;}while(v);while(n)s[p++]=t[--n];return p;}
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm,void *reserved){
 JNIEnv *e=0;
 if((*vm)->GetEnv(vm,(void**)&e,JNI_VERSION_1_6)!=JNI_OK || !e)return JNI_ERR;
 jclass process=(*e)->FindClass(e,"android/os/Process");if(!process)return JNI_ERR;
 jmethodID mypid=(*e)->GetStaticMethodID(e,process,"myPid","()I");if(!mypid)return JNI_ERR;
 jint pid=(*e)->CallStaticIntMethod(e,process,mypid);
 char text[192];unsigned p=append(text,0,"EXTERNAL_ARM32_JNI_ONLOAD_PASS\nPID=");p=decimal(text,p,(unsigned)pid);
 p=append(text,p,"\npointer_bytes=4\nsource=external-JDWP\n");text[p]=0;
 jclass str=(*e)->FindClass(e,"java/lang/String");if(!str)return JNI_ERR;
 jmethodID getbytes=(*e)->GetMethodID(e,str,"getBytes","(Ljava/lang/String;)[B");if(!getbytes)return JNI_ERR;
 jstring msg=(*e)->NewStringUTF(e,text),encoding=(*e)->NewStringUTF(e,"UTF-8");
 jbyteArray bytes=(jbyteArray)(*e)->CallObjectMethod(e,msg,getbytes,encoding);if((*e)->ExceptionCheck(e)||!bytes)return JNI_ERR;
 jclass file=(*e)->FindClass(e,"java/io/FileOutputStream");if(!file)return JNI_ERR;
 jmethodID ctor=(*e)->GetMethodID(e,file,"<init>","(Ljava/lang/String;)V"),write=(*e)->GetMethodID(e,file,"write","([B)V"),close=(*e)->GetMethodID(e,file,"close","()V");
 if(!ctor||!write||!close)return JNI_ERR;
 jstring path=(*e)->NewStringUTF(e,"/sdcard/Android/data/org.example.bs4armprobe/files/external-module-report.txt");
 jobject out=(*e)->NewObject(e,file,ctor,path);if((*e)->ExceptionCheck(e)||!out)return JNI_ERR;
 (*e)->CallVoidMethod(e,out,write,bytes);if((*e)->ExceptionCheck(e)){(*e)->ExceptionClear(e);(*e)->CallVoidMethod(e,out,close);return JNI_ERR;}
 (*e)->CallVoidMethod(e,out,close);if((*e)->ExceptionCheck(e))return JNI_ERR;
 return JNI_VERSION_1_6;
}
