package org.example.bs4armprobe;
import android.app.Activity;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.widget.TextView;
import java.io.*;
public final class MainActivity extends Activity {
 private static native String runNative();
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  StringBuilder r=new StringBuilder("BS4 ARM32 own-app execution test\nPID="+Process.myPid()+"\n");
  boolean pass=false;
  long observeAddress=0;
  try {
   System.loadLibrary("armprobe");
   String nativeResult=runNative();
   r.append(nativeResult).append('\n');
   pass=nativeResult.startsWith("ARM32_NATIVE_OK pointer_bytes=4 ") && nativeResult.endsWith("checksum=0x1d655466");
   int start=nativeResult.indexOf("buffer=0x")+9;
   long address=Long.parseLong(nativeResult.substring(start,start+8),16);
   observeAddress=address;
   byte[] bytes=new byte[256];
   RandomAccessFile mem=new RandomAccessFile("/proc/self/mem","r");mem.seek(address);mem.readFully(bytes);mem.close();
   long checksum=2166136261L;
   for(byte value:bytes) checksum=((checksum^(value&255))*16777619L)&0xffffffffL;
   boolean pointerPass=checksum==0x1d655466L;
   pass=pass && pointerPass;
   r.append("Independent Java read /proc/self/mem at ARM pointer: ").append(pointerPass?"PASS":"FAIL").append(" checksum=0x").append(Long.toHexString(checksum)).append('\n');
   RandomAccessFile elf=new RandomAccessFile(getApplicationInfo().nativeLibraryDir+"/libarmprobe.so","r");
   byte[] header=new byte[20];elf.readFully(header);elf.close();
   boolean elfPass=header[0]==127 && header[1]==69 && header[2]==76 && header[3]==70 && header[4]==1 && header[5]==1 && header[18]==40 && header[19]==0;
   pass=pass && elfPass;
   r.append("Installed library ELF32 ARM header: ").append(elfPass?"PASS":"FAIL").append('\n');
   r.append("Own process library mappings:\n");
   BufferedReader reader=new BufferedReader(new FileReader("/proc/self/maps"));
   String line;
   while((line=reader.readLine())!=null) if(line.contains("libarmprobe")||line.contains("libhoudini")||line.contains("libnb.so")) r.append(line).append('\n');
   reader.close();
  } catch(Throwable t) {
   pass=false;
   r.append("ERROR: ").append(Log.getStackTraceString(t)).append('\n');
  }
  r.append(pass?"RESULT: ARM32 EXECUTION AND OWN POINTER READ PASS\n":"RESULT: ARM32 EXECUTION OR OWN POINTER READ FAIL\n");
  r.append("Scope: normal JNI loading and independent own-process pointer read. External PID memory access and injection are not tested.\n");
  try { FileOutputStream f=openFileOutput("arm32-report.txt",MODE_PRIVATE); f.write(r.toString().getBytes("UTF-8")); f.close(); }
  catch(Exception e){r.append("Report save error: ").append(e).append('\n');}
  try { File dir=getExternalFilesDir(null); if(dir==null) throw new IOException("External files unavailable"); FileOutputStream f=new FileOutputStream(new File(dir,"arm32-report.txt")); f.write(r.toString().getBytes("UTF-8")); f.close(); } catch(Exception e){r.append("External report save error: ").append(e).append('\n');}
  if(pass && getIntent().getBooleanExtra("observe_write",false)) {
   final long address=observeAddress;
   final File directory=getExternalFilesDir(null);
   Thread observer=new Thread(new Runnable(){public void run(){
    try {
     RandomAccessFile memory=new RandomAccessFile("/proc/self/mem","r");
     try {
      for(int sequence=1;sequence<=600;sequence++){
       byte[] data=new byte[256];memory.seek(address);memory.readFully(data);long checksum=2166136261L;
       for(byte value:data)checksum=((checksum^(value&255))*16777619L)&0xffffffffL;
       String text="PID="+Process.myPid()+"\nsequence="+sequence+"\nfirst="+(data[0]&255)+"\nchecksum="+Long.toHexString(checksum)+"\n";
       File temp=new File(directory,"arm32-observer.tmp"),target=new File(directory,"arm32-observer.txt");
       FileOutputStream output=new FileOutputStream(temp);try{output.write(text.getBytes("UTF-8"));}finally{output.close();}
       if(!temp.renameTo(target))throw new IOException("Observer report rename failed");
       Thread.sleep(200);
      }
     }finally{memory.close();}
    }catch(Throwable error){Log.e("BS4ArmProbe","Observer failed",error);}
   }},"OwnBufferObserver");
   observer.setDaemon(true);observer.start();
  }
  for(String line:r.toString().split("\n")) Log.i("BS4ArmProbe",line);
  TextView view=new TextView(this);view.setText(r.toString());view.setTextSize(14);view.setPadding(20,20,20,20);setContentView(view);
 }
}
