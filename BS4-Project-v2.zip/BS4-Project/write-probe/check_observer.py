from pathlib import Path
import subprocess,time
p=Path('D:/ааааа/чичи/arm32-probe/write-probe');adb=r'C:\Program Files\BlueStacks_bgp64\HD-Adb.exe';log=[]
def run(*args):
 r=subprocess.run([adb,'-s','emulator-5556',*map(str,args)],capture_output=True,timeout=30)
 text=(r.stdout+r.stderr).decode('utf-8',errors='replace').replace('\r','');log.append('$ adb '+' '.join(map(str,args))+'\n'+text)
 if r.returncode:raise RuntimeError(text)
 return text
def parse(text):return dict(line.split('=',1) for line in text.splitlines() if '=' in line)
run('install','-r',p/'outputs/BS4-ARM32-Write-Test.apk')
run('shell','am force-stop org.example.bs4armprobe')
run('shell','rm -f /sdcard/Android/data/org.example.bs4armprobe/files/arm32-observer.txt')
run('shell','am start -W -n org.example.bs4armprobe/.MainActivity --ez observe_write true')
a=run('shell','cat /sdcard/Android/data/org.example.bs4armprobe/files/arm32-observer.txt');time.sleep(.6)
b=run('shell','cat /sdcard/Android/data/org.example.bs4armprobe/files/arm32-observer.txt')
x,y=parse(a),parse(b)
assert x['PID']==y['PID']==run('shell','pidof org.example.bs4armprobe').strip()
assert x['checksum']==y['checksum']=='1d655466'
assert int(y['sequence'])>int(x['sequence'])
result='ANDROID OBSERVER BASELINE PASS: live own process; matching known checksum; sequence advances. No external write was performed.'
log.append(result)
(p/'outputs/android-observer-baseline.txt').write_text('\n'.join(log),encoding='utf-8');print('\n'.join(log))
# Discard this preliminary watcher; the actual EXE starts a fresh own process for its 120-second observation window.
run('shell','am force-stop org.example.bs4armprobe')
