from pathlib import Path
p=Path('D:/ааааа/чичи/arm32-probe/write-probe/src/Windows-ARM32-Write-Probe.cs');s=p.read_text()
s=s.replace('Handle=OpenProcess(0x410,false,Process.GetCurrentProcess().Id)', 'Handle=OpenProcess(0x438,false,Process.GetCurrentProcess().Id)')
s=s.replace('   bool rejected=false;try{ram.Read(0x900000,1);}', '''   ram.WriteOwnByte(0x800ffe,0x12,0x48);Assert(ram.Read(0x800ffe,1)[0]==0x48,"own Windows byte write through mapped synthetic RAM");
   ram.WriteOwnByte(0x800ffe,0x48,0x12);Assert(ram.Read(0x800ffe,1)[0]==0x12,"own Windows byte restoration");
   bool rejected=false;try{ram.WriteOwnByte(0x800ffe,0xff,0x49);}catch{rejected=true;}Assert(rejected&&ram.Read(0x800ffe,1)[0]==0x12,"unexpected-byte write rejected without mutation");
   rejected=false;try{ram.Read(0x900000,1);}''')
s=s.replace('These are not live external ARM32 tests.', 'Own Windows byte write/restoration also passed. These are not live emulator write tests.')
p.write_text(s,encoding='utf-8')
