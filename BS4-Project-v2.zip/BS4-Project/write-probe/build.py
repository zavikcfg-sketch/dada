from pathlib import Path
import subprocess, os, zipfile, struct, hashlib
root=Path(__file__).resolve().parent
jdk=next((root.parent/'tools/jdk').iterdir());bt=root.parent/'tools/buildtools/android-11';platform=root.parent/'tools/platform/android-7.1.1/android.jar'
# Use the actual extracted directories rather than relying on archive folder names.
bt=next((root.parent/'tools/buildtools').rglob('aapt.exe')).parent
platform=next((root.parent/'tools/platform').rglob('android.jar'))
b=root/'build';out=root/'outputs';(b/'classes').mkdir(exist_ok=True);(b/'dex').mkdir(exist_ok=True)
def run(args):
 print(' '.join(map(str,args)),flush=True)
 subprocess.run([os.path.relpath(a,root) if i>0 and isinstance(a,Path) and a.is_absolute() else str(a) for i,a in enumerate(args)],check=True,cwd=root)
java=jdk/'bin/java.exe'
run([jdk/'bin/javac.exe','-encoding','UTF-8','-source','8','-target','8','-bootclasspath',platform,'-d',b/'classes',root/'src/MainActivity.java'])
run([java,'-cp',bt/'lib/d8.jar','com.android.tools.r8.D8','--min-api','24','--lib',platform,'--output',b/'dex',*sorted((b/'classes').rglob('*.class'))])
run([bt/'aapt.exe','package','-f','-M',root/'src/AndroidManifest.xml','-I',platform,'-F',b/'unsigned.apk'])
with zipfile.ZipFile(b/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 z.write(b/'dex/classes.dex','classes.dex')
 z.write(b/'lib/armeabi-v7a/libarmprobe.so','lib/armeabi-v7a/libarmprobe.so')
run([bt/'zipalign.exe','-f','4',b/'unsigned.apk',b/'aligned.apk'])
key=b/'test-key.p12'
if not key.exists():
 run([jdk/'bin/keytool.exe','-genkeypair','-keystore',key,'-storetype','PKCS12','-storepass','armprobe-local-test','-alias','armprobe','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=Local ARM32 Test'])
run([java,'-jar',bt/'lib/apksigner.jar','sign','--ks',key,'--ks-pass','pass:armprobe-local-test','--ks-key-alias','armprobe','--out',out/'BS4-ARM32-Write-Test.apk',b/'aligned.apk'])
run([java,'-jar',bt/'lib/apksigner.jar','verify','--verbose',out/'BS4-ARM32-Write-Test.apk'])
run([bt/'aapt.exe','dump','badging',out/'BS4-ARM32-Write-Test.apk'])
elf=(b/'lib/armeabi-v7a/libarmprobe.so').read_bytes()
assert elf[:7]==b'\x7fELF\x01\x01\x01'
assert struct.unpack_from('<H',elf,18)[0]==40
assert struct.unpack_from('<I',elf,36)[0]>>24==5
shoff=struct.unpack_from('<I',elf,32)[0];shsize,shnum=struct.unpack_from('<HH',elf,46)
sections=[struct.unpack_from('<10I',elf,shoff+i*shsize) for i in range(shnum)]
exports=[];undefined=[]
for sh in sections:
 if sh[1]!=11:continue
 strings=sections[sh[6]];st=elf[strings[4]:strings[4]+strings[5]]
 for i in range(sh[5]//sh[9]):
  name,val,size,info,other,idx=struct.unpack_from('<IIIBBH',elf,sh[4]+i*sh[9])
  sym=st[name:].split(b'\0')[0].decode()
  if sym and idx:exports.append(sym)
  elif sym:undefined.append(sym)
assert 'JNI_OnLoad' in exports and 'Java_org_example_bs4armprobe_MainActivity_runNative' in exports
assert not undefined,undefined
print('ELF CHECK PASS: ELF32 ARM EABI5; JNI exports present; no undefined dynamic symbols.',flush=True)
print('APK SHA256:',hashlib.sha256((out/'BS4-ARM32-Write-Test.apk').read_bytes()).hexdigest(),flush=True)
