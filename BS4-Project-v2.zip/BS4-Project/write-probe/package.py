from pathlib import Path
import subprocess,zipfile
base=Path('D:/ааааа/чичи/arm32-probe');p=base/'write-probe';source=p/'src/Windows-ARM32-Write-Probe.cs';s=source.read_text()
s=s.replace('Dictionary<uint,ulong> chunks=new Dictionary<uint,ulong>();','Dictionary<uint,ulong> chunks=new Dictionary<uint,ulong>();Dictionary<uint,ulong> chunkNodes=new Dictionary<uint,ulong>();')
s=s.replace('chunks.Add(id,host);','chunks.Add(id,host);chunkNodes.Add(id,node);')
s=s.replace('    return host+((ulong)(id&511)<<12)+(physical&4095);','    if(H32(chunkNodes[id>>9])!=(id>>9)||H64(chunkNodes[id>>9]+0x30)!=host)throw new Exception("RAM chunk mapping changed; refusing stale snapshot");\n    return host+((ulong)(id&511)<<12)+(physical&4095);')
s=s.replace('   attempted=true;ram.WriteOwnByte(physical,expected[0],changed[0]);','   if(!ram.Virtual(id.Root,meta.Address,256).SequenceEqual(expected))throw new Exception("Known own buffer changed before mutation");\n   attempted=true;ram.WriteOwnByte(physical,expected[0],changed[0]);')
source.write_text(s,encoding='utf-8')
exe=p/'outputs/Windows-ARM32-Write-Probe.exe'
subprocess.run(['C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe','/nologo','/platform:x64','/optimize+','/target:exe','/out:'+str(exe),str(source)],check=True)
subprocess.run([str(exe),'--self-test'],check=True)
(p/'outputs/README.txt').write_text('''Обратимая запись ОДНОГО байта в известный буфер СОБСТВЕННОГО ARM32-приложения.

Распакуй весь ZIP, оставь один BlueStacks 4, запусти Windows-ARM32-Write-Probe.exe
и подтверди UAC. Дождись Saved. Пришли windows-arm32-write-report.txt.

Программа обновляет только org.example.bs4armprobe, запускает новый процесс,
находит его адресное пространство по PID и проверяет ELF32 ARM/256 байт буфера.
Затем меняет первый байт буфера 88 -> 2. Приложение независимо читает свою память
через /proc/self/mem и публикует новую контрольную сумму. В finally программа
восстанавливает байт 2 -> 88 и требует нового подтверждения Android-наблюдателя.
Проверяются свежие PID, таблицы страниц, физический адрес и состояние RAM-дескрипторов.
При смене идентичности/адреса восстановление по устаревшему адресу не выполняется.
При RESTORE NOT CONFIRMED нужно закрыть своё тестовое приложение: буфер исчезнет
вместе с процессом. Игра не является целью; выбор чужого PID не предусмотрен.

Успех полного теста:
RESULT: WINDOWS OWN ARM32 ONE-BYTE WRITE AND RESTORE PASS

Проверено помощником:
- сборка APK/EXE, ELF32 ARM EABI5;
- самопроверки адресации, реальной записи/восстановления своей Windows-памяти,
  проверки отказа при неожиданном байте, разбор Android-наблюдателя;
- настоящий запуск APK: PID 7374, observer sequence 2 -> 5, checksum 1d655466.
НЕ проверена помощником запись в память BlueStacks: Windows отказала в правах,
Win32=5. Её должен подтвердить запуск EXE от администратора.

Это ещё не инжектор: кодовые страницы, регистры CPU, хуки и исполнение кода
в другом процессе не изменяются. Проверяется только байт в своём буфере.
Поддерживается точная проверенная сборка BlueStacks 4.220.0.4001 и ядро 4.9.95
Wed Jul 29 12:42:21 IST 2020. Несовпадение профиля вызывает отказ.

APK версии 3 содержит собственный Java-наблюдатель. Предыдущий модульный
тест версии 2 при повторной установке потребует обновления APK.
Источники и build.py приложены; инструменты ../tools не включены.
Самопроверка: Windows-ARM32-Write-Probe.exe --self-test
Проверка прав без UAC/изменений в эмуляторе: Windows-ARM32-Write-Probe.exe --preflight
''',encoding='utf-8')
archive=base/'outputs/Windows-ARM32-Write-Probe.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in (p/'outputs').iterdir():
  if f.is_file() and f.suffix!='.idsig':z.write(f,'Windows-ARM32-Write-Probe/'+f.name)
 for f in (p/'src').iterdir():
  if f.is_file():z.write(f,'Windows-ARM32-Write-Probe/src/'+f.name)
 z.write(p/'build.py','Windows-ARM32-Write-Probe/build.py')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;print('ZIP verified:',len(z.namelist()),'files;',archive.stat().st_size,'bytes')
