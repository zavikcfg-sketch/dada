import urllib.request, json, zipfile, concurrent.futures, hashlib
from pathlib import Path
p=Path('D:/ааааа/чичи/arm32-probe/tools')
jdk=next(x for x in json.loads((p/'jdk.json').read_text()) if '-ca-jdk' in x['name'] and 'win_x64' in x['name'])
items=[('jdk',jdk['download_url'],None),('buildtools','https://dl.google.com/android/repository/91936d4ee3ccc839f0addd53c9ebf087b1e39251.build-tools_r30.0.3-windows.zip','fc165c721b8d2da55e6fede467526c81f562be7b'),('platform','https://dl.google.com/android/repository/platform-25_r03.zip','00c2c5765e8988504be10a1eb66ed71fcdbd7fe8')]
def get(item):
 name,url,sha=item
 dest=p/(name+'.zip')
 print('Downloading',name,flush=True)
 urllib.request.urlretrieve(url,dest)
 if sha: assert hashlib.sha1(dest.read_bytes()).hexdigest()==sha
 with zipfile.ZipFile(dest) as z: z.extractall(p/name)
 print('Ready',name,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 list(pool.map(get,items))
