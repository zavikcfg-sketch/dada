import io,zipfile,urllib.request,concurrent.futures,time
from pathlib import Path
root=Path('D:/ааааа/чичи/arm32-probe/tools')
class Remote(io.RawIOBase):
 def __init__(self,url,size):self.url=url;self.size=size;self.pos=0
 def seekable(self):return True
 def readable(self):return True
 def tell(self):return self.pos
 def seek(self,n,w=0):self.pos=n if w==0 else self.pos+n if w==1 else self.size+n;return self.pos
 def part(self,pair):
  a,b=pair
  for attempt in range(4):
   try:
    req=urllib.request.Request(self.url,headers={'Range':f'bytes={a}-{b}'})
    with urllib.request.urlopen(req,timeout=10) as r:
     data=r.read();assert len(data)==b-a+1
     return data
   except Exception:
    if attempt==3: raise
 def read(self,n=-1):
  if n<0:n=self.size-self.pos
  n=min(n,self.size-self.pos)
  if n<=0:return b''
  pairs=[(a,min(a+8192,self.pos+n)-1) for a in range(self.pos,self.pos+n,8192)]
  with concurrent.futures.ThreadPoolExecutor(max_workers=24) as pool: data=b''.join(pool.map(self.part,pairs))
  self.pos+=len(data)
  return data
items=[('platform','platform-25_r03.zip',85424763,lambda n:n.endswith('/android.jar')),('buildtools','91936d4ee3ccc839f0addd53c9ebf087b1e39251.build-tools_r30.0.3-windows.zip',54254759,lambda n:n.endswith(('/aapt.exe','/zipalign.exe','/lib/d8.jar','/lib/apksigner.jar')) or n.endswith('.dll'))]
def go(it):
 name,url,size,select=it
 z=zipfile.ZipFile(Remote('https://dl.google.com/android/repository/'+url,size))
 for n in z.namelist():
  if select(n):
   print('Extracting',n,flush=True)
   d=z.read(n);dest=root/name/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(d)
   print('Ready',n,len(d),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(go,items))
