import urllib.request, concurrent.futures, hashlib, zipfile
from pathlib import Path
p=Path('D:/ааааа/чичи/arm32-probe/tools')
items=[('buildtools','91936d4ee3ccc839f0addd53c9ebf087b1e39251.build-tools_r30.0.3-windows.zip',54254759,'fc165c721b8d2da55e6fede467526c81f562be7b'),('platform','platform-25_r03.zip',85424763,'00c2c5765e8988504be10a1eb66ed71fcdbd7fe8')]
def download(it):
 name,url,size,sha=it
 step=1024*1024
 def chunk(start):
  end=min(start+step,size)-1
  for attempt in range(3):
   try:
    req=urllib.request.Request('https://dl.google.com/android/repository/'+url,headers={'Range':f'bytes={start}-{end}'})
    with urllib.request.urlopen(req,timeout=30) as r:
     assert r.status==206
     data=r.read()
     assert len(data)==end-start+1
     return data
   except Exception:
    if attempt==2: raise
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: data=b''.join(pool.map(chunk,range(0,size,step)))
 assert hashlib.sha1(data).hexdigest()==sha
 f=p/(name+'-range.zip');f.write_bytes(data)
 with zipfile.ZipFile(f) as z: z.extractall(p/name)
 print('Ready',name,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: list(pool.map(download,items))
