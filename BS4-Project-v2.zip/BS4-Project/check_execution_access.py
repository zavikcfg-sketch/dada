import subprocess,concurrent.futures
adb=r'C:\Program Files\BlueStacks_bgp64\HD-Adb.exe'
commands={
'identity':'id; getprop ro.debuggable; getprop ro.dalvik.vm.native.bridge',
'game':'pidof com.axlebolt.standoff2; dumpsys package com.axlebolt.standoff2 | grep -E "versionName=|primaryCpuAbi=|flags=|pkgFlags="',
'own':'pidof org.example.bs4armprobe; dumpsys package org.example.bs4armprobe | grep -E "versionName=|primaryCpuAbi=|flags=|pkgFlags="',
'policy':'getenforce; cat /proc/sys/kernel/yama/ptrace_scope; ls -l /system/bin/run-as'
}
def run(item):
 name,cmd=item
 try:
  r=subprocess.run([adb,'-s','emulator-5556','shell',cmd],capture_output=True,timeout=8)
  return name,(r.stdout+r.stderr).decode('utf-8',errors='replace')
 except Exception as e:return name,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:
 for name,result in p.map(run,commands.items()):print(name+'\n'+result,flush=True)
try:
 r=subprocess.run([adb,'-s','emulator-5556','jdwp'],capture_output=True,timeout=3)
 print('jdwp\n'+r.stdout.decode())
except subprocess.TimeoutExpired as e:
 print('jdwp snapshot\n'+(e.stdout or b'').decode())
