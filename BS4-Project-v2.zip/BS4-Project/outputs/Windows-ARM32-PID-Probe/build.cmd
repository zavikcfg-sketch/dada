@echo off
"%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /platform:x64 /optimize+ /target:exe /out:"%~dp0Windows-ARM32-PID-Probe.exe" "%~dp0Windows-ARM32-PID-Probe.cs"
exit /b %errorlevel%
