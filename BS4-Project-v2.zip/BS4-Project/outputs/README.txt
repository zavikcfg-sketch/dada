Проверено в BlueStacks 4.220.0.4001, ADB emulator-5556, Android API 25.
Пакет: org.example.bs4armprobe. Это отдельное тестовое приложение.

Результат запуска: ARM32 EXECUTION AND OWN POINTER READ PASS.
PID=5642, буфер=0x0c130450, размер=256, FNV-1a=0x1d655466.
Библиотека ELF32 ARM EABI5, ABI armeabi-v7a, без внешних динамических символов.
JNI_OnLoad и JNI-метод экспортируются. APK подписан тестовым ключом.
ARM32-код вычислил контрольную сумму. Java независимо прочитала те же байты через /proc/self/mem.
Присутствуют libhoudini.so и libnb.so в собственном процессе.

Ограничение: это штатная загрузка JNI из своего APK. Чтение извне по PID из Windows и инжекция НЕ проверены.
Старые исходники Android-PID-Probe-v3 отсутствуют; этот пакет их не восстанавливает.

Отчёт приложения: arm32-report.txt. Фактический logcat: arm32-logcat.txt.
install-report.txt содержит вывод установки и запуска; build-report.txt — сборку и проверки.
В observed-game-renderer-crash.txt сохранён увиденный при первом запуске краш ДРУГОГО процесса:
com.axlebolt.standoff2, PID 2824, RenderThread, libpga.so/PgaSocketFlush/glReadPixels.
По одному этому логу нельзя установить причину или связь с запуском тестового приложения.

run-as в этой сборке возвращает Could not set capabilities: Operation not permitted.
Поэтому итоговый файл сохранён приложением в собственной внешней папке:
/sdcard/Android/data/org.example.bs4armprobe/files/arm32-report.txt

Повторный запуск установленного приложения:
adb -s emulator-5556 shell am force-stop org.example.bs4armprobe
adb -s emulator-5556 shell am start -W -n org.example.bs4armprobe/.MainActivity
adb -s emulator-5556 pull /sdcard/Android/data/org.example.bs4armprobe/files/arm32-report.txt

Удаление только тестового приложения:
adb -s emulator-5556 uninstall org.example.bs4armprobe

Для сборки использованы Zig 0.13.0 (C/Clang, cortex_a9, softfp, -nostdlib),
JDK 17, Android platform 25, Android build-tools 30.0.3. Инструменты находятся отдельно
в D:/ааааа/чичи/arm32-probe/tools и в ZIP не включены.
