BS4 Project v2

Последний результат и область работы: PROJECT-STATUS.txt.
Внешняя загрузка в собственный DEBUGGABLE APK: jdwp-loader/run.cmd.
Подробности: jdwp-loader/README.txt; лог реального запуска:
jdwp-loader/outputs/external-load-report.txt.

Внутри весь сохранившийся проект: исходники C/C#/Java/Python, EXE, ARM32 .so,
APK и отчёты. SDK, дистрибутивы инструментов, кеши и вложенные ZIP исключены.
Windows-инструменты и Android-пакет имеют обычные имена и исходники рядом.
Отдельный игровой инжектор и функции ESP/aimbot не реализованы.

Целевой проверенный стенд: BlueStacks 4.220.0.4001, ядро 4.9.95
Wed Jul 29 12:42:21 IST 2020. Другие сборки не проверены.
