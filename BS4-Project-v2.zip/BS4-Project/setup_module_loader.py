from pathlib import Path
import shutil
base=Path('D:/ааааа/чичи/arm32-probe');p=base/'module-loader'
for n in ['src','build/lib/armeabi-v7a','build/include','outputs']: (p/n).mkdir(parents=True,exist_ok=True)
for n in ['jni_md.h','stdio.h']: shutil.copyfile(base/'build/include'/n,p/'build/include'/n)
shutil.copyfile(base/'build/lib/armeabi-v7a/libarmprobe.so',p/'build/lib/armeabi-v7a/libarmprobe.so')
shutil.copyfile(base/'build/test-key.p12',p/'build/test-key.p12')
manifest=(base/'src/AndroidManifest.xml').read_text().replace('android:versionCode="1"','android:versionCode="2"').replace('android:versionName="1.0"','android:versionName="2.0"')
(p/'src/AndroidManifest.xml').write_text(manifest,encoding='utf-8')
s=(base/'src/MainActivity.java').read_text()
s=s.replace('private static native String runNative();','private static native String runNative();\n private static native String pluginResult(int nonce);\n private static final String PLUGIN_SHA256="HASH_PLACEHOLDER";')
s=s.replace('r.append(pass?"RESULT: ARM32 EXECUTION AND OWN POINTER READ PASS\\n":"RESULT: ARM32 EXECUTION OR OWN POINTER READ FAIL\\n");', '''r.append(pass?"RESULT: ARM32 EXECUTION AND OWN POINTER READ PASS\\n":"RESULT: ARM32 EXECUTION OR OWN POINTER READ FAIL\\n");
  if(getIntent().getBooleanExtra("load_plugin",false)) {
   boolean loaded=false;
   try {
    if(!pass) throw new IOException("Base ARM32 test failed");
    File incoming=new File(getExternalFilesDir(null),"libarmplugin.so");
    if(incoming.length()<20 || incoming.length()>1048576) throw new IOException("Missing module or invalid length");
    FileInputStream input=new FileInputStream(incoming);
    ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] chunk=new byte[4096];int n;
    try {while((n=input.read(chunk))!=-1){bytes.write(chunk,0,n);if(bytes.size()>1048576)throw new IOException("Module too large");}} finally {input.close();}
    byte[] binary=bytes.toByteArray();
    byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest(binary);
    StringBuilder hash=new StringBuilder();for(byte value:digest)hash.append(String.format(java.util.Locale.US,"%02x",value&255));
    if(!hash.toString().equals(PLUGIN_SHA256))throw new SecurityException("Module SHA256 mismatch");
    r.append("MODULE SHA256 VERIFIED: ").append(hash).append('\\n');
    File destination=new File(getDir("probe_modules",MODE_PRIVATE),"libarmplugin.so");
    FileOutputStream write=new FileOutputStream(destination);try{write.write(binary);write.getFD().sync();}finally{write.close();}
    System.load(destination.getAbsolutePath());
    int nonce=new java.security.SecureRandom().nextInt();
    String answer=pluginResult(nonce);
    String expected=String.format(java.util.Locale.US,"ARM32_PLUGIN_OK pointer_bytes=4 onload=1 nonce=%08x response=%08x",nonce,nonce^0xa55a1234);
    r.append(answer).append('\\n');
    if(!answer.equals(expected))throw new IOException("JNI response mismatch");
    BufferedReader maps=new BufferedReader(new FileReader("/proc/self/maps"));boolean mapped=false;String line;
    try {while((line=maps.readLine())!=null)if(line.contains("/libarmplugin.so")){r.append(line).append('\\n');mapped=true;}}finally{maps.close();}
    if(!mapped)throw new IOException("Loaded module absent from own process maps");
    loaded=true;
   } catch(Throwable t) { r.append("MODULE ERROR: ").append(Log.getStackTraceString(t)).append('\\n'); }
   r.append(loaded?"RESULT: OWN ARM32 MODULE LOAD PASS\\n":"RESULT: OWN ARM32 MODULE LOAD FAIL\\n");
  }''')
s=s.replace('External PID memory access and injection are not tested.','This run does not test external PID memory access or injection. Module loading uses this own application interface.')
(p/'src/MainActivity.java').write_text(s,encoding='utf-8')
s=(base/'build.py').read_text();s=s.replace("root/'tools/", "root.parent/'tools/")
s=s.replace("BS4-ARM32-Probe.apk", "BS4-ARM32-Module-Test.apk")
s=s.replace("root=Path(__file__).resolve().parent", "root=Path(__file__).resolve().parent")
(p/'build.py').write_text(s,encoding='utf-8')
